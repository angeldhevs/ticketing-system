const mix = require('laravel-mix');

mix.disableNotifications();
/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel application. By default, we are compiling the Sass
 | file for the application as well as bundling up all the JS files.
 |
 */

//App.css
mix.sass('resources/sass/app.scss', 'public/css');

mix.sass('resources/sass/ticket/view.scss', 'public/css');

mix.js('resources/js/lib.js', 'public/js');

//Components
mix.js([
   'resources/js/components/dialog-box.js',
   'resources/js/components/spinner.js',
   'resources/js/components/navigation.js',
], 'public/js/components.js');

//Utilities
mix.js([
   'resources/js/utils/extension-methods.js',
   'resources/js/utils/form-validation.js',
], 'public/js/utils.js');

//Ticket Module
mix.js([
   'resources/js/ticket/index.js',
   'resources/js/ticket/create.js',
   'resources/js/ticket/update.js',
], 'public/js/modules/tickets.js');

//Manage User Module
mix.js([
   'resources/js/admin/manage/users/index.js',
   'resources/js/admin/manage/users/form.js',
], 'public/js/modules/manage/users.js');

//Manage Role Module
mix.js([
   'resources/js/admin/manage/roles/index.js',
   'resources/js/admin/manage/roles/create.js',
], 'public/js/modules/manage/roles.js');

//Reports Module
mix.js([
   'resources/js/reports/index.js',
], 'public/js/modules/reports.js');


 //Dashboard Module
mix.js([

      'resources/js/dashboard/dashboard.js',
   'resources/js/dashboard/charts/tickets-per-status.js',
   'resources/js/dashboard/charts/tickets-per-severity.js',
   'resources/js/dashboard/charts/recent-ticket-updates.js',
   'resources/js/dashboard/charts/new-vs-closed-tickets.js',
], 'public/js/modules/dashboard.js');