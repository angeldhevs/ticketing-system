<div id="tickets-per-date" class="card dashboard-chart" data-source="{{ route('api.dashboard.tickets-per-date') }}">
        <div class="card-header">
          <strong class="card-title">Ticket Analytics</strong>
        </div>
        <div class="card-body">
          <canvas height="300"></canvas>
      </div>
      </div>
