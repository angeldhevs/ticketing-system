<div class="align-self-right order-2 col-md-2">
    <div class="input-group m-0 p-0">
        <div class="input-group-prepend">
            <div class="input-group-text">
                <span class="fa fa-calendar"></span>
            </div>
        </div>
        <input type="text" readonly="readonly" name="date-range" class="form-control form-control-sm readonly">
    </div>
</div>
