<nav id="sidebar-left" class="sidebar sidebar-dark shadow accordion">
  <div class="sidebar-header text-center">
    <span class="app-name">
        {{ config('app.name') }}
    </span>
  </div>
  @if(Auth::user()->has_role('admin'))
    @include('shared.menu.admin')
  @elseif(Auth::user()->has_role('team leader'))
    @include('shared.menu.team-leader')
  @elseif(Auth::user()->has_role('agent'))
    @include('shared.menu.agent')
  @endif
  <ul class="nav flex-column sticky-bottom">
    <li class="nav-item">
      <a class="nav-link" href="#">
        <i class="fa fa-tools" aria-hidden="true"></i> <span>Settings</span>
      </a>
    </li>
  </ul>
</nav>