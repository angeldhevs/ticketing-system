<ul class="nav flex-column">
  <li class="nav-item">
    <a class="nav-link" href="{{ route('dashboard') }}">
      <i class="fa fa-tachometer-alt" aria-hidden="true"></i> <span>Dashboard</span>
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ route('tickets.index') }}">
      <i class="fa fa-ticket-alt" aria-hidden="true"></i> <span>Tickets</span>
    </a>
  </li>
</ul>
