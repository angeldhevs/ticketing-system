<ul class="nav flex-column">
  <li class="nav-item">
    <a class="nav-link" href="{{ route('dashboard') }}">
      <i class="fa fa-tachometer-alt" aria-hidden="true"></i> Dashboard
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="/reports">
      <i class="fa fa-chart-bar" aria-hidden="true"></i> Reports
    </a>
  </li>
</ul>