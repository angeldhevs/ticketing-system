<footer class="pt-2 mb-4">
  <hr />
  <div class="text-center">
    <small class="text-muted">Copyright © 2019</small>
  </div>
</footer>