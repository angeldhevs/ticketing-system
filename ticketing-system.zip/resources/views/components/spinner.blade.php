<div id="spinner">
    <div class="spinner-border spinner-border-lg" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>