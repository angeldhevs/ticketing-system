<div id="ticket-progress">
  @if ($ticket_progress->count() > 0)
  <div class="row p-1">
    <div class="form-group col-sm-12 text-muted">
      <strong>History: </strong>
        <ul class="list-group">
        @foreach ($ticket_progress as $progress)
        @php($status = $progress->status)
          <li class="list-group-item list-group-item-{{ $status_context[$status->id - 1] }}">
            <div class="d-flex w-100 justify-content-between align-items-center">
              <h6 class="mb-1">
                <strong>
                  @switch($status->name)
                  @case("New")
                    Ticket added to system.
                    @break
                    @case("Open")
                      Ticket assigned to {{ $progress->asignee->name }} by {{ $progress->reporter->name }}.
                      @break
                    @case("In Progress")
                      Ticket is in progress.
                      @break
                    @case("Needs More Info")
                      Ticket needs more information.
                      @break
                    @case("Resolved")
                      Ticket marked as resolved.
                      @break
                    @case("Closed")
                      Ticket marked as closed.
                      @break
                    @default
                  @endswitch
                </strong>
              </h6>
            <span class="badge badge-{{ $status_context[$status->id - 1] }}">{{ $status->name }}</span>
          </div>
          <div class="d-flex w-100 justify-content-between align-items-center">
            <span class="text-muted">{{ $progress->remarks }}</span>
            <span class="pull-right">{{ $progress->created_at->diffForHumans() }}</span>
          </div>
        </li>
        @endforeach
    </ul>
  </div>
</div>
@endif
</div>
