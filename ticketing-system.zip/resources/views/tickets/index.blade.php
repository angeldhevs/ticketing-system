@php
$is_admin = Auth::user()->has_role('admin');
@endphp

@extends('layouts.app', [
  'pageTitle' => 'Tickets',
  'header' => [
    'icon' => 'fa-ticket-alt',
    'text' => $is_admin ? 'All Tickets' : 'My Tickets'
  ]
])

@section('content')
<div class="container-fluid">
  <div class="dt-wrapper">
    <div class="dt-top-bar row">
      <div class="col col-sm-12 col-md-4 order-xs-last">
        <div class="input-group mb-2">
            <div class="input-group-prepend">
              <div class="input-group-text">
                <i class="fa fa-search"></i>
              </div>
            </div>
            <input type="search" name="searh" class="form-control form-control-sm col-10" aria-controls="tickets" placeholder="Search here" />
        </div>
      </div>
      <div class="col col-sm-12 col-md-8 order-xs-first text-right">
        <div class="button-group" role="group">
          @if($is_admin)
          <span data-toggle="tooltip" data-placement="right" title="New Ticket">
            <button type="button" class="btn btn-light border fa fa-plus"  data-toggle="modal" data-target="#ticket-form" ></button>
          </span>
          @endif
        </div>
      </div>
    </div>
    <table class="table table-striped table-hover" style="width:100%" data-source="{{ route('api.tickets.index') }}">
        <thead>
            <tr>
                <th>Ticket #</th>
                <th>Title</th>
                <th>Severity</th>
                <th>Status</th>
                <th>Last Update</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        {{-- @foreach($tickets as $ticket)
            <tr>
                <td>
                    <a href="/tickets/{{ $ticket->id}}">
                        {{ $ticket->ticket_number }}
                    </a>
                </td>
                <td>
                    {{ $ticket->title }}
                    <br />
                    <small class="text-muted">Added {{ $ticket->created_at->diffForHumans() }}</small>
                </td>
                <td>{{ $ticket->severity->name }}</td>
                <td>{{ $ticket->current()->status->name }}</td>
                <td>{{ $ticket->current()->created_at }}</td>
                <td>

                  @if($is_admin && $ticket->current()->status_id == 1)
                        <a href="/tickets/{{  $ticket->id }}" class="alert-danger fa fa-eye" data-toggle="tooltip" data-placement="right" title="View Ticket Details" ></a>
                  @else
                        <a href="/tickets/{{  $ticket->id }}" class="fa fa-eye" data-toggle="tooltip" data-placement="right" title="View Ticket Details" ></a>
                  @endif

                </td>
            </tr>
        @endforeach --}}
        </tbody>
    </table>
  </div>
</div>
@if($is_admin)
@include('tickets.create', $createTicket)
@endif
@endsection


@push('scripts')
<script type="text/javascript" src="{{ asset('js/modules/tickets.js') }}" ></script>
@endpush
