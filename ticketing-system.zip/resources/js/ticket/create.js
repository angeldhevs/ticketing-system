"use strict";

//Create local scope to prevent polluting the global namespace.
$(function() {
  let options = {
    tinymce: {
      selector: '[name=ticket_details]',
      height: 500,
      menubar: false,
      theme: "basic",
      plugins: [
        'advlist autolink lists link image charmap print preview anchor textcolor',
        'searchreplace visualblocks code fullscreen',
        'insertdatetime media table paste code help wordcount'
      ],
      toolbar: 'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
      content_css: [
        '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
        '//www.tiny.cloud/css/codepen.min.css'
      ]
    }
  }

  //Cache DOM references
  let $document = $(document);
  let $modal = $document.find('#ticket-form');
  let $form = $modal.find('form');

  function initialize() {
    $form.validation();
    bindEvents();
    render();
  }

  function bindEvents() {
    $form.on('submit', submitAsync.bind(this));
  }

  function render() {
  }

  function submitAsync(e) {
    e.preventDefault();
    let data = $form.createObject();

    if($form.valid()) {
      $.post({
        url: $form.attr('action'),
        data: data,
        dataType: 'json',
        contentType: 'json',
        success: showSuccessMessage.bind(this),
        error: showErrorMessage.bind(this)
      });
    }
    return false;
  }

  function showSuccessMessage(data, status, xhr) {
    $.alertBox('success', {
      title: 'Success!',
      content: data.message || 'Ticket successfully created!',
      onDestroy: reloadPage.bind(this)
    });
  }

  function showErrorMessage(data, status, xhr) {
    console.log(data);
    $.alertBox('error', {
      title: 'Oops!',
      content: data.message || 'There was a problem creating the ticket.',
    });
  }

  function reloadPage() {
    location.reload();
  }

  initialize();

});
