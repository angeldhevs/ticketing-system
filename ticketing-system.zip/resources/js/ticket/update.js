/**
 * Update Ticket Module
 *
 */

"use strict";

$(function () {
  $('#modalUpdateTicket').on('shown.bs.modal', function (e) {
    var link = $(e.relatedTarget);
    console.log($('#ticket_id').val());
    $('#status option').each(function() {
      if($(this).val() == link.data("id")) {
        $(this).prop("selected", true);
      }
    });
  });

  $('#btnUpdateTicket').click(function (e) {
    var url = "/tickets/{tickets}";
    var formData = {
      ticket_id: $('#ticket_id').val(),
      status_id: $('#status option:selected').val(),
      assignee_id: $('#assignee_id').val(),
      reported_id: $('#reporter_id').val(),
      remarks: $('#ticket_remarks').val(),
    };
    console.log(formData);
    var type = "PUT";
    var my_url = url;
    $.ajax({
      type: type,
      url: my_url,
      data: formData,
      dataType: 'json',
      success: function (data) {
          console.log(data);
          $('#modalUpdateTicket').remove();
          location.reload();
      },
      error: function (data) {

      }
    });
  });
});