/*!
 * extension-methods v1.0.0
 * Author: Benedict Semilla
 * Contact: benedict.11394@gmail.com
 */
; (function($, undefined) {
 /**
  * Creates a javascript object using the form fields.
  */
 $.fn.createObject = function(obj) {
    return $(this)
      .serializeArray()
      .reduce(function(a, x) { 
          a[x.name] = x.value; 
          return a; 
      }, obj || {});
  }

})(jQuery);


