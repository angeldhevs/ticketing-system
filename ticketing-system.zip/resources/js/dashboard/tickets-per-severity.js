/**
 * Tickets Per Severity Pie Chart
 * Dependencies: jQuery, Chart.js
 */
"use strict";

$(function() {

    //Initialize module default options.
    let options = {
        ajax: {
            type: 'GET',
            dataType: 'json',
            success: refreshChart.bind(this),
            timeout: 2000,
        },
        polling: {
            interval: 5000
        },
        chart: {
            type: 'pie',
            data: {
                datasets: [{
                    label: 'Severities',
                    backgroundColor: [
                        '#6c757d', //Unclassified
                        '#17a2b8', //Low
                        '#007bff', //Medium
                        '#ffc107', //High
                        '#dc3545', //Critical
                    ]
                }],
            },
            options: {
                respponsive: true,
                maintainAspectRatio: true,
                legend: {
                    display: true,
                    position: 'right'
                },
            },
        },
        moment: {
            format: 'YYYY-MM-DD'
        }
    };

    //Variables
    let chart = null;
    let poller = null;
    let $request = null;

    //Cache jQuery DOM references.
    let $root = $('#dashboard');
    let $daterange = $root.find('input[name=date-range]');
    let $target = $root.find('#tickets-per-severity')
    let $canvas = $target.find('canvas');
    let daterangepicker = $daterange.data('daterangepicker');

    function initialize() {
        $.extend(true, options.ajax, {
            url: $target.data('source'),
            data: {
                from: daterangepicker.startDate.format(options.moment.format),
                to: daterangepicker.endDate.format(options.moment.format)
            },
            complete: poll.bind(this)
        });
        bindEvents();
        render();
    }

    function bindEvents() {
        $daterange.on('apply.daterangepicker', updateChart.bind(this));
    }

    function render() {
        $request = $.ajax(options.ajax);
    }

    function poll() {
        poller = setTimeout(function() {
            $request = $.ajax(options.ajax);
        }, options.polling.interval);
    }

    function cancelPolling() {
        $request.abort();
        clearTimeout(poller);
    }

    function refreshChart(dt) {
        let chartData = {
            datasets: [{
                label: 'Status',
                data: dt.data.map(d => d.ticket_count),
                backgroundColor: options.chart.data.datasets[0].backgroundColor
            }],
            labels: dt.data.map(d => d.name)
        };

        if(!chart) {
            let canvas = $canvas.get(0);
            let context = canvas.getContext('2d');
            let settings = $.extend(true, {
                data: chartData
            }, options.chart);
            chart = new Chart(context, settings);
        } else {
            let curData = chart.data.datasets[0].data;
            let newData = chartData.datasets[0].data;

            if(curData.length !== newData.length || !curData.every(function(d, i) { return newData[i] === d; })) {
                chart.data = chartData;
                chart.update();
            }
        }
    }

    function updateChart(evt, picker) {
        cancelPolling();
        $.extend(true, options.ajax, {
            data: {
                from: picker.startDate.format(options.moment.format),
                to: picker.endDate.format(options.moment.format)
            }
        });
        render();
    }

    initialize();
});
