/**
 * Recent Ticket Updates
 */

$(function() {
  //Initialize module default options.
  let options = {
    datatable: {
      ajax: {
        dataSrc: 'data'
      },
      columns: [
        {
          data: 'ticket_number',
          title: 'Ticket #',
          type: 'number',
          width: 70,
          render: function (data, type, obj, meta) {
              return `<a href="${obj.links.view}">${data}</a>`;
          }
        },
        {
          data: 'ticket_status',
          title: 'Status',
          width: 80,
        },
        {
          data: 'ticket_asignee',
          title: 'Asignee',
          width: 80,
        },
        {
          data: 'date_last_updated',
          title: 'Updated',
          type: 'datetime-moment',
          width: 100,
          render: function(data, type, obj, meta) {
              return hd.relativeTime(data);
          } 
        }
      ],
      scrollY: 250,
      scrollCollapse: true,
      dom: 't',
      paging: false,
      ordering: false,
      searching: false,
      info: false,
    },
    polling: {
      interval: 1000
    }
  };

  //Cache jQuery DOM references.
  $root = $('#recent-ticket-updates');
  $table = $root.find('table');

  function initialize() {
    $.extend(true, options.datatable.ajax, { url: $root.data('source') });
    bindEvents();
    render();
  }

  function bindEvents() {

  }

  function render() {
    $table.DataTable(options.datatable);
  }

  initialize();
});