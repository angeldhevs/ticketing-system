"use strict";

/**
 * Tickets by Status Pie Chart
 * Dependencies: jQuery, Chart.js
 */

; (function($) {

  $(function() {
    let options = {
      ajax: {
        type: 'GET',
        dataType: 'json',
        success: refreshChart.bind(this),
        complete: poll.bind(this)
      },
      polling: {
        interval: 5000
      },
      chart: {
        type: 'doughnut',
        data: {
          datasets: [{
            label: 'Status',
            backgroundColor: [
              '#6c757d', //New
              '#007bff', //Open
              '#17a2b8', //In Progress
              '#dc3545', //Needs More Info
              '#ffc107', //Resolved
              '#28a745', //Closed
            ]
          }],
        },
        options: {
          legend: {
            display: true,
            position: 'right',
            align: 'center',
            labels: {
              boxWidth: 15,
            }
          }
        }
      }
    };
  
    let ajax = null;
    let poller = null;
  
    let $root = $('#tickets-by-status');
    let $canvas = $root.find('canvas');
    let chart = null;
  
    function initialize() {
      $.extend(true, options.ajax, { url: $root.data('source') });
      render();
    }
  
    function render() {
      ajax = $.ajax(options.ajax);
    }
  
    function poll() {
      poller = setTimeout(function() {
        ajax = $.ajax(options.ajax);
      }.bind(this), options.polling.interval);
    }
  
    function refreshChart(dt, status, xhr) {
      let chartData = {
        datasets: [{
          data: dt.data.map(d => d.ticket_count),
          backgroundColor: options.chart.data.datasets[0].backgroundColor
        }],
        labels: dt.data.map(d => d.name)
      };
  
      if(!chart) {
        let canvas = $canvas.get(0);
        let context = canvas.getContext('2d');
        let settings = $.extend(true, { data: chartData }, options.chart);
        chart = new Chart(context, settings);
      } else {
        let curData = chart.data.datasets[0].data;
        let newData = chartData.datasets[0].data;
  
        if(curData.length !== newData.length && !curData.every((d, i) => newData[i] === d)) {
          chart.data = chartData;
          chart.update();
        }
      }
    }
  
    initialize();
  });

})(jQuery);

