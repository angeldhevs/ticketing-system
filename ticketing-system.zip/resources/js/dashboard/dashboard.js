/**
 * Dashboard Layout (via Gridstack)
 */

$(function() {
  //Initialize module default options.
  let options = {
    gridstack: {
      staticGrid: true,
      animate: true,
      verticalMargin: 16
    }
  };

  //Cache jQuery DOM references.
  $root = $('#dashboard');

  function initialize() {
    render();
  }

  function render() {
  }

  initialize();
});