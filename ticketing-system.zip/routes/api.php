<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::fallback(function(Request $request) {
    return response()->json([
        'message' => 'The resource you are looking for does not exist in the server.'
    ], 404);
});

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::resource('users', 'UsersController');
Route::resource('roles', 'RolesController');
Route::resource('tickets', 'TicketsController');
Route::resource('ticket-status', 'TicketStatusController');
Route::resource('ticket-severities', 'TicketSeveritiesController');

Route::prefix('dashboard')
->name('dashboard.')
->group(function() {
    Route::get('summary', 'DashboardController@getSummaryDetails')->name('summary');
    Route::get('tickets-per-date', 'DashboardController@getTicketsPerDate')->name('tickets-per-date');
    Route::get('tickets-per-status', 'DashboardController@getTicketsPerStatus')->name('tickets-per-status');
    Route::get('tickets-per-severity', 'DashboardController@getTicketsPerSeverity')->name('tickets-per-severity');
    Route::get('recent-ticket-updates', 'DashboardController@getRecentTicketUpdates')->name('recent-ticket-updates');
    Route::get('new-vs-closed-tickets', 'DashboardController@getNewVsClosedTickets')->name('new-vs-closed-tickets');
});
