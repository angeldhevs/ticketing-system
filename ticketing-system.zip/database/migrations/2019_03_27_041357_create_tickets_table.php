<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTicketsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('ticket_number')->nullable(false);
            $table->string('title')->nullable(false);
            $table->string('client_name')->nullable(false);
            $table->string('client_email')->nullable(false);
            $table->longText('details')->nullable();
            $table->bigInteger('source_id')->unsigned()->nullable(false);
            $table->bigInteger('severity_id')->unsigned()->nullable(false);
            $table->bigInteger('current_status_id')->unsigned()->nullable(false);
            $table->foreign('source_id')->references('id')->on('ticket_sources');
            $table->foreign('severity_id')->references('id')->on('ticket_severities');
            $table->foreign('current_status_id')->references('id')->on('ticket_status');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tickets');
    }
}
