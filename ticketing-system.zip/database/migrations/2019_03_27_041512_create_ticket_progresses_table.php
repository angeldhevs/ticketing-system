<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTicketProgressesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ticket_progress', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('ticket_id')->unsigned()->nullable(false);
            $table->bigInteger('status_id')->unsigned()->nullable(false);
            $table->bigInteger('asignee_id')->unsigned()->nullable(true);
            $table->bigInteger('reporter_id')->unsigned()->nullable(true);
            $table->foreign('ticket_id')->references('id')->on('tickets');
            $table->foreign('status_id')->references('id')->on('ticket_status');
            $table->foreign('asignee_id')->references('id')->on('users');
            $table->foreign('reporter_id')->references('id')->on('users');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ticket_progress');
    }
}
