<?php

use Illuminate\Database\Seeder;
use App\Models\Tickets\TicketProgress;
use App\Models\Admin\Manage\RoleUser;
use Faker\Factory as Faker;
use App\Models\Tickets\TicketStatus;
use App\Models\Tickets\Ticket;

class TicketProgressSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        $tickets = Ticket::all();
        $statuses = TicketStatus::orderBy('id', 'asc')->get();
        $asignee_ids = RoleUser::where('role_id', 3)->get()->pluck('user_id');
        $reporter_ids = RoleUser::where('role_id', 1)->get()->pluck('user_id');

        foreach($tickets as $ticket) {
            $date = new DateTime();
            $asignee_id = $faker->randomElement($asignee_ids);
            $reporter_id = $faker->randomElement($reporter_ids);

            $date->sub(new DateInterval('PT'.rand(0,23).'H'.rand(0,59).'M'.rand(0,59).'S'));

            $current_status = $ticket->severity->id > 1 ? 
                $faker->randomElement(array_slice($statuses->all(), 1, 5)) :
                $statuses[0];

            $ticket->timestamps = false;
            $ticket->update([ 
                'updated_at' => $date->format('Y-m-d H:i:s'),
                'current_status_id' => $current_status->id
            ]);

            do {
                TicketProgress::create([
                    'ticket_id' => $ticket->id,
                    'status_id' => $current_status->id,
                    'asignee_id' => $asignee_id,
                    'reporter_id' => $reporter_id,
                    'remarks' => $faker->paragraph(1),
                    'created_at' => $date->format('Y-m-d H:i:s'),
                    'updated_at' => $date->format('Y-m-d H:i:s')
                ]);

                //Evaluate next status, based on the status flow.
                if($current_status->prev_status->count() === 0) {
                    break;
                }

                $prev_statuses = $current_status->prev_status->all();
                $current_status = $prev_statuses[rand(0, max(count($prev_statuses), 1) - 1)];
                $date->sub(new DateInterval('PT'.rand(0,23).'H'.rand(0,59).'M'.rand(0,59).'S'));
            } while($current_status != null);

            $ticket->update([ 'created_at' => $date->format('Y-m-d H:i:s') ]);
            $ticket->timestamps = true;
        }
    }
}
