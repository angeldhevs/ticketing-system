<?php

use Illuminate\Database\Seeder;
use App\Models\Tickets\TicketSeverity;

class TicketSeveritiesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('ticket_severities')->delete();

        TicketSeverity::create(array('name' => 'Unclassified'));
        TicketSeverity::create(array('name' => 'Low'));
        TicketSeverity::create(array('name' => 'Medium'));
        TicketSeverity::create(array('name' => 'High'));
        TicketSeverity::create(array('name' => 'Critical'));
    }
}
