<?php

use Illuminate\Database\Seeder;
use App\Models\Admin\Manage\User;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->delete();
        // factory(User::class, 50)->create();
        User::create([ 'name'  => 'Oliver L. Lyons', 'email' => 'In@magnaCras.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Rhoda N. Sandoval', 'email' => 'in@parturient.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Tatiana N. Kelly', 'email' => 'eu.ultrices.sit@pulvinararcu.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Shaeleigh Z. Vance', 'email' => 'in.tempus.eu@arcuSed.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Myles M. Elliott', 'email' => 'sem.egestas.blandit@liberoduinec.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Leo V. Bruce', 'email' => 'Suspendisse.sed.dolor@Craseget.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Neil M. Franks', 'email' => 'Fusce@ipsumprimisin.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Meghan D. Whitney', 'email' => 'tortor@lobortisauguescelerisque.net' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Keelie J. Lott', 'email' => 'sed.dui.Fusce@utodio.net' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Hyatt X. Patrick', 'email' => 'risus.Morbi@facilisisnon.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Ronan V. Meyer', 'email' => 'semper.erat.in@mipedenonummy.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Hayes Q. Griffin', 'email' => 'at.lacus.Quisque@placerateget.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Bianca G. Bates', 'email' => 'libero@libero.net' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Maia L. Blackburn', 'email' => 'mollis.vitae@vitaediam.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Sebastian G. Gardner', 'email' => 'molestie.sodales@porttitorvulputateposuere.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Marny M. Winters', 'email' => 'Mauris.ut.quam@SuspendisseduiFusce.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Cheryl I. Schwartz', 'email' => 'Aliquam.gravida.mauris@massa.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Merrill H. Delacruz', 'email' => 'id.risus@lacinia.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Laurel Q. Monroe', 'email' => 'tristique.ac@quislectus.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Howard M. Leach', 'email' => 'luctus.vulputate@vel.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Ciara M. Palmer', 'email' => 'viverra.Donec@nequepellentesque.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Kennan K. Robinson', 'email' => 'ipsum.sodales@ultricies.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Aline C. Sanchez', 'email' => 'natoque.penatibus.et@rutrumurna.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Chava U. Mack', 'email' => 'amet.luctus.vulputate@diamPellentesque.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Kyla C. Yates', 'email' => 'quam.dignissim@amet.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Olivia O. Mason', 'email' => 'sed.dui@velit.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Devin G. Deleon', 'email' => 'magna.Lorem@nonenim.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Karly U. Glenn', 'email' => 'Nunc.pulvinar@ornare.co.uk' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Althea O. Dorsey', 'email' => 'sodales.Mauris.blandit@Nullaeget.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Eric P. Steele', 'email' => 'dolor.egestas@odio.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Shelley S. Ortiz', 'email' => 'lectus@molestietellusAenean.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Grant L. Lynch', 'email' => 'fringilla.purus.mauris@IntegerurnaVivamus.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Ethan W. Hinton', 'email' => 'in.hendrerit@mi.co.uk' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'TaShya N. Dunlap', 'email' => 'consequat.enim.diam@est.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Darryl M. Greene', 'email' => 'Integer@Nam.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Aristotle F. Foreman', 'email' => 'eget@egestasurna.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Hunter I. Curry', 'email' => 'cursus.Integer.mollis@leo.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Merrill X. Tate', 'email' => 'vitae@Aeneanegestashendrerit.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Tiger K. Garcia', 'email' => 'orci@semperNam.net' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Sybill Q. Dickson', 'email' => 'a@quistristique.net' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Kimberly D. Dawson', 'email' => 'egestas@aenim.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Quamar Z. Bradshaw', 'email' => 'eu@risusMorbi.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Martena N. Scott', 'email' => 'ultricies.sem@anteNuncmauris.co.uk' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Tyler H. Dotson', 'email' => 'ipsum@mi.net' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Patrick G. Fleming', 'email' => 'amet.luctus@elementum.net' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Glenna Y. Mayer', 'email' => 'Integer.id@Curabitur.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Ariel A. Dickerson', 'email' => 'Ut@diamvel.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Ezra Y. Robbins', 'email' => 'dolor.Fusce@venenatis.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Raya P. Roman', 'email' => 'eu@ac.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Christopher X. Holden', 'email' => 'nec@Donecfringilla.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'MacKensie R. Waller', 'email' => 'nec.malesuada@diamat.co.uk' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Neil B. Oneil', 'email' => 'Sed.auctor@Morbi.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Caleb M. Chavez', 'email' => 'aliquet.molestie@ut.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Jonah F. Morales', 'email' => 'nec@estNuncullamcorper.net' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Alden A. Craig', 'email' => 'elementum@velitAliquamnisl.co.uk' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Leah Q. Alvarado', 'email' => 'diam@Integervulputate.net' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Michael D. Barber', 'email' => 'et@ridiculusmusDonec.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Hope M. Rollins', 'email' => 'Proin.dolor@leo.net' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Jaime S. Gonzales', 'email' => 'mauris@vulputateposuere.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Yoshi C. Briggs', 'email' => 'mauris.ut@mus.co.uk' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Damian J. Mccormick', 'email' => 'Fusce@feugiat.co.uk' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Caleb G. Gay', 'email' => 'mauris.sit.amet@aliquam.net' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Damian Q. Lyons', 'email' => 'at.iaculis.quis@convallis.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Hu P. Hall', 'email' => 'non@atiaculisquis.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Wylie C. Mathis', 'email' => 'fringilla.est.Mauris@ligulaAliquamerat.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Stewart C. Adkins', 'email' => 'enim.Etiam@ligulaAliquamerat.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Erich R. Arnold', 'email' => 'ante.ipsum@luctus.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Todd O. Osborn', 'email' => 'dapibus.ligula@Suspendisseac.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Wilma P. Adkins', 'email' => 'sagittis@diam.co.uk' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Ciaran C. Glenn', 'email' => 'pellentesque.Sed@Nuncsedorci.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Mari K. Smith', 'email' => 'Integer@Aliquamrutrum.co.uk' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Devin C. Bradford', 'email' => 'molestie.tortor@metussit.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Vernon Y. Aguilar', 'email' => 'magna@sapienNuncpulvinar.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Hashim S. Mann', 'email' => 'nisl@egestashendreritneque.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Yetta W. Clay', 'email' => 'orci@orciinconsequat.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Kenneth J. Browning', 'email' => 'sit@aliquamarcuAliquam.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Amir G. Morris', 'email' => 'elit.Etiam@Vestibulum.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Ulla U. Jacobson', 'email' => 'metus.Aenean.sed@Suspendissealiquet.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Alec V. Gilliam', 'email' => 'a@Suspendisseseddolor.co.uk' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Callie M. Massey', 'email' => 'magnis@tellussem.net' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Wyoming R. Roman', 'email' => 'ligula.Aenean.gravida@velvulputateeu.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Rae E. Ramsey', 'email' => 'ac@facilisisfacilisis.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Holmes Q. Wilson', 'email' => 'vestibulum.massa@ante.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Malcolm M. Garza', 'email' => 'nec@egetnisidictum.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Byron Q. Lancaster', 'email' => 'mauris@eliteratvitae.co.uk' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Isaiah G. Hudson', 'email' => 'quam@odioAliquam.net' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Uriah G. Wood', 'email' => 'eu.tellus.Phasellus@ornarefacilisis.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Colby C. Carr', 'email' => 'iaculis.quis@congueelitsed.co.uk' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Shay Q. Ward', 'email' => 'libero.est.congue@malesuadaaugue.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Akeem A. Noel', 'email' => 'lorem.semper.auctor@natoque.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Gavin S. Battle', 'email' => 'at@egetodio.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'India K. Yates', 'email' => 'Nunc@nislNulla.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Nelle W. Soto', 'email' => 'vel.lectus.Cum@a.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Richard H. Waters', 'email' => 'ante@vitae.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Edan C. Ewing', 'email' => 'tellus@scelerisque.org' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Ivana F. Richardson', 'email' => 'pharetra@eu.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Lyle I. Madden', 'email' => 'magna@consectetuer.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Josephine C. Ferguson', 'email' => 'consectetuer.euismod@euultrices.com' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Ross K. Espinoza', 'email' => 'urna.et.arcu@magnaDuis.edu' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
        User::create([ 'name'  => 'Katell E. Moore', 'email' => 'Aliquam.erat.volutpat@eliterat.ca' , 'password' => '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm' ]);
    }
}
