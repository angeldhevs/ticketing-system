<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use App\Models\Admin\Manage\User;
use App\Models\Admin\Manage\Role;
use App\Models\Admin\Manage\RoleUser;

class RoleUserSeeder extends Seeder
{
/**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        $userIds = User::all()->pluck('id');
        $roleIds = Role::all()->pluck('id');

        foreach ($userIds as $userId) {
            RoleUser::create([
                'user_id' => $userId,
                'role_id' => $roleIds[$userId % $roleIds->count()]
            ]);
        }
    }
}
