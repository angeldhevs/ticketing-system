<?php

use Illuminate\Database\Seeder;
use App\Models\Tickets\Ticket;
use Faker\Factory as Faker;

class TicketSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        $sources = DB::table('ticket_sources')->pluck('id');
        $severities = DB::table('ticket_severities')->pluck('id');
        $current_status_id = DB::table('ticket_status')->first()->id;

        foreach (range(1,20) as $index) {
            Ticket::create([
                'ticket_number' => strval(100000 + $index),
                'title' => implode(' ', $faker->words(10)),
                'client_name' => $faker->name,
                'client_email' => $faker->email,
                'details' => $faker->paragraph(1),
                'severity_id' => $faker->randomElement($severities),
                'source_id' => $faker->randomElement($sources),
                'current_status_id' => $current_status_id
            ]);
        }
    }
}
