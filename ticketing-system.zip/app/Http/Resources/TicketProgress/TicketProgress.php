<?php

namespace App\Http\Resources\TicketProgress;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\TicketStatus\TicketStatus;
use App\Http\Resources\User\User;

class TicketProgress extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'status' => TicketStatus::make($this->status),
            'asignee' => User::make($this->asignee),
            'reporter' => User::make($this->reporter)
        ];
    }
}
