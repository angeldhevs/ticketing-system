<?php

namespace App\Http\Resources\Ticket;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\TicketProgress\TicketProgress;

class TicketDetails extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'ticket_number' => $this->ticket_number,
            'ticket_title' => $this->title,
            'ticket_source' => $this->source->name,
            'ticket_severity' => $this->severity->name,
            'ticket_status' => $this->status->name,
            'ticket_reporter' => $this->current()->reporter->name,
            'ticket_asignee' => $this->current()->asignee->name,
            'ticket_progress' => TicketProgress::collection($this->progress),
            'client_name' => $this->client_name,
            'client_email' => $this->client_email,
            'date_issued' => (string) $this->created_at,
            'date_last_updated' => (string) $this->updated_at
        ];
    }
}
