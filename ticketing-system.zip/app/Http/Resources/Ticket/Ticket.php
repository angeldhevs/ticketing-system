<?php

namespace App\Http\Resources\Ticket;

use Illuminate\Http\Resources\Json\JsonResource;

class Ticket extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $links = [
            'edit' => route('tickets.edit', [ 'id' => $this->id ]),
            'view' => route('tickets.show', [ 'id' => $this->id ]),
        ];

        return [
            'id' => $this->id,
            'ticket_number' => $this->ticket_number,
            'ticket_title' => $this->title,
            'ticket_source' => $this->source->name,
            'ticket_severity' => $this->severity->name,
            'ticket_status' => $this->status->name,
            'ticket_reporter' => $this->current()->reporter->name,
            'ticket_asignee' => $this->current()->asignee->name,
            'client_name' => $this->client_name,
            'client_email' => $this->client_email,
            'date_issued' => $this->created_at->format('Y-m-d H:i:s'),
            'date_last_updated' => $this->current()->created_at->format('Y-m-d H:i:s'),
            'links' => $links
        ];
    }
}
