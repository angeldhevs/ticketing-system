<?php

namespace App\Http\Controllers\Api;

use App\Http\Resources\Ticket\TicketCollection;
use App\Models\Tickets\Ticket;
use App\Models\Tickets\TicketProgress;
use App\Http\Controllers\Api\ApiController;
use App\Http\Requests\Tickets\CreateTicketRequest;
use App\Http\Requests\Tickets\UpdateTicketRequest;
use App\Models\Tickets\TicketStatus;
use App\Http\Resources\Ticket\Ticket as TicketResource;

class TicketsController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return TicketCollection::make(Ticket::all()->sortByDesc('created_at'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CreateTicketRequest $request)
    {
        $ticket = new Ticket();

        $status_id = TicketStatus::where('name', 'New')->first()->id;

        $ticket = Ticket::create([
            'ticket_number' => Ticket::orderBy('ticket_number', 'desc')->first()->ticket_number + 1,
            'title'         => $request['ticket_title'],
            'client_name'   => $request['client_name'],
            'client_email'  => $request['client_email'],
            'details'       => $request['ticket_details'],
            'source_id'     => 1,
            'severity_id'   => $request['severity_id'],
            'current_status_id' => $status_id
        ]);

        $progress = TicketProgress::create([
            'ticket_id' => $ticket->id,
            'status_id' => $status_id,
            'asignee_id' => $request['agent_id'],
            'reporter_id' => $request->user()->id,
            'remarks' => $request['ticket_details']
        ]);

        return TicketResource::make($ticket);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Ticket $ticket)
    {
        return TicketResource::make($ticket);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateTicketRequest $request, Ticket $ticket)
    {
        DB::transaction(function() use ($request, $ticket) {

            $ticket->update($request->only(['ticket_title', 'severity_id', 'details']));

            if($ticket->source->name === "Email") {
                $ticket->update($request->only(['client_name', 'client_email']));
            }
            $ticket->save();

            $ticket_progress = new TicketProgress();
            $ticket_progress->ticket_id = $ticket->id;
            $ticket_progress->fill($request->only($ticket_progress->getFillable()));
            $ticket_progress->save();
        });

        return TicketResource::make($ticket);
    }
}
