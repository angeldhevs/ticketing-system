<?php

namespace App\Http\Controllers\Api;

use App\Models\Tickets\TicketStatus;
use App\Http\Resources\TicketStatus\TicketStatusCollection;
use App\Http\Resources\TicketStatus\TicketStatus as TicketStatusResource;
use App\Http\Requests\TicketStatus\UpdateTicketStatusRequest;
use App\Http\Requests\TicketStatus\StoreTicketStatusRequest;
use App\Http\Controllers\Api\ApiController;

class TicketStatusController extends ApiController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return TicketStatusCollection::make(TicketStatus::all()->sortBy('id'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreTicketStatusRequest $request)
    {
        $status = $request->persist(new TicketStatus());
        return TicketStatusResource::make($status);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(TicketStatus $ticketStatus)
    {
        return TicketStatusResource::make($ticketStatus);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateTicketStatusRequest $request, TicketStatus $ticketStatus)
    {
        $status = $request->persist($ticketStatus);
        return TicketStatusResource::make($ticketStatus);
    }
}
