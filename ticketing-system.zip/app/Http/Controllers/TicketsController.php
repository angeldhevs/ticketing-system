<?php

namespace App\Http\Controllers;

use App\Models\Tickets\TicketProgress;
use App\Models\Tickets\TicketStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use App\Models\Tickets\Ticket;
use App\Models\Admin\Manage\User;
use App\Models\Admin\Manage\Role;
use App\Models\Tickets\TicketSource;
use App\Models\Tickets\TicketSeverity;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Tickets\CreateTicketRequest;
use App\Http\Requests\Tickets\UpdateTicketRequest;
use App\Http\Requests\Tickets\AssignTicketRequest;

class TicketsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $user = Auth::user();
        $data = [];

        if($user->has_role('admin')) {
            $data['title'] = 'All Tickets';
            $data['tickets'] = Ticket::all()->sortByDesc('ticket_number');
            $data['createTicket'] = [
                'sources' => TicketSource::where('name', 'Email')->get(),
                'severities' =>  TicketSeverity::all()->toArray(),
                'agents' => User::whereHas('roles', function($query) {
                    $query->where('name', '=', 'agent');
                })->get()->toArray()
            ];
        } else {
            $data['title'] = 'Your Tickets';
            $data['tickets'] = $user->tickets();
        }

        return view('tickets.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {

        $data = [
            'source_id' => TicketSource::where('name', 'Team Leader')->first()->id,
            'severities' => TicketSeverity::all()->toArray(),
            'agents' => Role::with('users')->where('name', 'Agent')->get()->toArray()
        ];

        return view("tickets.create")->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  App\Http\Requests\Tickets\CreateTicketRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CreateTicketRequest $request)
    {
        DB::transaction(function() use ($request) {
            $status_id = TicketStatus::where('name', 'New')->first()->id;

            $ticket = Ticket::create([
                'ticket_number' => Ticket::orderBy('ticket_number', 'desc')->first()->ticket_number + 1,
                'title'         => $request['ticket_title'],
                'client_name'   => $request['client_name'],
                'client_email'  => $request['client_email'],
                'details'       => $request['ticket_details'],
                'source_id'     => $request['source_id'],
                'severity_id'   => $request['severity_id'],
                'current_status_id' => $status_id
            ]);

            TicketProgress::create([
                'ticket_id' => $ticket->id,
                'status_id' => $status_id,
                'asignee_id' => $request['agent_id'],
                'reporter_id' => Auth::user()->id,
                'remarks' => $request['ticket_details']
            ]);

            $ticket->touch();

            return redirect()->route('tickets.show', [ 'id' => $ticket->id ]);
        });
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $agents = Role::with('users')->where('name', 'Agent')->get()->toArray();
        $data = [
            'ticket' => Ticket::find($id),
            'ticket_status' =>  TicketStatus::all(),
            'agents' => $agents[0]['users'],
            'severities' => TicketSeverity::all()
        ];

        return view('tickets.view')->with($data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = [
            'ticket' => Ticket::find($id),
            'ticket_status' =>  TicketStatus::all(),
            'severities' => TicketSeverity::all()->toArray(),
            'agents' => Role::with('users')->where('name', 'Agent')->get()->toArray()
        ];

        return view('tickets.edit')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateTicketRequest $request, $id)
    {
        if($request->validated()) {
            $ticket = Ticket::find($id);

            $ticket->title          = $request['ticket_title'];
            $ticket->severity_id    = $request['severity_id'];
            $ticket->details        = $request['details'];

            if($ticket->source->name === "Email") {
                $ticket->client_name    = $request['client_name'];
                $ticket->client_email   = $request['client_name'];
            }

            TicketProgress::create([
                'ticket_id'         => $id,
                'status_id'         => $request['status_id'],
                'asignee_id'        => $request['assignee_id'],
                'reporter_id'       => $request['reported_id'],
                'remarks'           => $request['remarks'],
            ]);

            return redirect()->route('tickets.show', [ 'id' => $id ]);
        }
    }

    /**
     * Assigns the specified ticket to an agent.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function assign(AssignTicketRequest $request, $id)
    {
        if($request->validated()) {
            DB::transaction(function() use ($request, $id) {
                $ticket = Ticket::find($id);

                TicketProgress::create([
                    'ticket_id' => $ticket->id,
                    'status_id' => TicketStatus::where('name', 'Open')->first()->id,
                    'asignee_id' => $request['agent_id'],
                    'reporter_id' => Auth::user()->id,
                    'remarks' => $request['ticket_details']
                ]);

                return redirect()->route('tickets.show', [ 'id' => $ticket->id ]);
            });

            TicketProgress::create([
                'ticket_id' => $request['ticket_id'],
                'status_id' => $request['status_id'],
                'asignee_id' => $request['assignee_id'],
                'reporter_id' => $request['reported_id'],
                'remarks' => $request['remarks'],
            ]);
            return redirect()->route('tickets.show', [ 'id' => $id ]);
        }
    }

    public function assigned(Request $request)
    {
        TicketProgress::create([
            'ticket_id' => $request['ticket_id'],
            'status_id' => $request['status_id'],
            'asignee_id' => $request['assignee_id'],
            'reporter_id' => Auth::user()->getAuthIdentifier(),
        ]);
        Ticket::find($request['ticket_id'])->update([
            'severity_id' => $request['severity_id']
        ]);

        return 0;
    }

}
