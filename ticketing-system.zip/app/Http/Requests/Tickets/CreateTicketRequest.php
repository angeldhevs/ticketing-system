<?php

namespace App\Http\Requests\Tickets;

use App\Http\Requests\ApiRequest;

class CreateTicketRequest extends ApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
        // return $this->user()->has_role('admin', 'team_leader');
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [];
        // return [
        //     'ticket_title' => [
        //         'required',
        //         'max:255'
        //     ],
        //     'client_name' => [
        //         'required'
        //     ],
        //     'client_email' => [
        //         'required'
        //     ],
        //     'severity_id' => [
        //         'required'
        //     ],
        //     'agent_id' => [
        //         'required'
        //     ],
        // ];
    }

    public function messages()
    {
        return [
            'ticket_title.requred' => 'Title is required',
            'client_name.required' => 'Client name is required',
            'client_email.required' => 'Client email is required',
            'severity_id.required' => 'Severity is required',
            'agent_id.required' => 'Agent is required'
        ];
    }
}
