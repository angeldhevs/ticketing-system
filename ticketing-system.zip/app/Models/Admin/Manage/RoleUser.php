<?php

namespace App\Models\Admin\Manage;

use Illuminate\Database\Eloquent\Relations\Pivot;

/**
 * Represents the relationship between a user and a role.
 */
class RoleUser extends Pivot
{
    protected $table = 'role_user';
    public $incrementing = true;

    protected $fillable = [
        'user_id', 'role_id'
    ];

    public function user() {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function role() {
        return $this->belongsTo(Role::class, 'role_id', 'id');
    }
}
