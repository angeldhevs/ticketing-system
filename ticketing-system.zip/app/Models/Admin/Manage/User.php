<?php

namespace App\Models\Admin\Manage;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Models\Tickets\TicketProgress;
use Illuminate\Support\Facades\DB;
use App\Models\Admin\Manage\RoleUser;
use Laravel\Passport\HasApiTokens;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\SoftDeletes;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable, SoftDeletes;

    protected $fillable = [ 'name', 'email', 'password' ];

    protected $hidden = [ 'password', 'remember_token' ];

    protected $casts = [ 'email_verified_at' => 'datetime' ];

    /**
     * Returns the roles assigned to the current user.
     */
    public function roles() {
        return $this->belongsToMany(Role::class)
                    ->using(RoleUser::class)
                    ->withTimestamps();
    }

    /**
     * Determines if the user is assigned to the specified role/s.
     */
    public function has_role($roleNames) {
        $roles = $this->roles;
        $roleNames = is_array($roleNames) ? array_map('strtolower', $roleNames) : $roleNames;

        foreach ($roles as $role) {
            if(
                (is_array($roleNames) && in_array(strtolower($role->name), $roleNames))
                ||
                (is_string($roleNames) && strcasecmp($roleNames, $role->name) == 0)
                ) {
                return true;
            }
        }
        return false;
    }

    public function tickets() {
        $latest_progress = TicketProgress::select('ticket_id', DB::raw(' MAX(created_at) as max_date'))
            ->groupBy('ticket_id');

        $recent = $this
            ->hasMany(TicketProgress::class, 'asignee_id')
            ->joinSub($latest_progress, 'latest_progress', function($q) {
                $q->on('latest_progress.ticket_id', '=', 'ticket_progress.ticket_id')
                  ->on('latest_progress.max_date', '=', 'ticket_progress.created_at');
            })
            ->get();

        return $recent->pluck('ticket');
    }

    public function count_tickets()
    {
        $latest_progress = TicketProgress::select('ticket_id', DB::raw(' MAX(created_at) as max_date'))
            ->groupBy('ticket_id');

        $recent = $this
            ->hasMany(TicketProgress::class, 'asignee_id')
            ->joinSub($latest_progress, 'latest_progress', function($q) {
                $q->on('latest_progress.ticket_id', '=', 'ticket_progress.ticket_id')
                    ->on('latest_progress.max_date', '=', 'ticket_progress.created_at');
            })->where('ticket_progress.status_id',4)
            ->get();

        return $recent->count();
    }

    public static function storeFromRequest(Request $request)
    {
        $instance = parent::storeFromRequest($request);

        RoleUser::create([
            'role_id' => $request['role_id'],
            'user_id' => $instance->id
        ]);
    }

    public static function updateFromRequest(Request $request, $id)
    {
        $instance = parent::updateFromRequest($request, $id);

        if($instance) {
            $user_role = $instance->roles->first();
            $user_role->update($request->only(['role_id']))->save();
        }

        return $instance;
    }
}
