<?php

namespace App\Models\Admin\Manage;

use App\Models\Admin\Manage\RoleUser;
use App\Models\ModelBase;

class Role extends ModelBase
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [ 'name' ];

    /**
     * The users that were assigned to this role.
     *
     * @var array
     */
    public function users() {
        return $this->belongsToMany(User::class)
                    ->using(RoleUser::class)
                    ->withPivot(['created_at', 'updated_at']);
    }
}
