<?php

namespace App\Models\Tickets;

use App\Models\Tickets\TicketProgress;
use App\Models\ModelBase;
use App\Models\Tickets\TicketStatusFlow;

/**
 * Represents a possible status of a ticket in its lifetime.
 */
class TicketStatus extends ModelBase
{
    protected $table = 'ticket_status';

    protected $fillable = [ 'name', 'description' ];

    /**
     * Returns an array of status that is mapped as the next status.
     */
    public function next_status() {
        return $this->belongsToMany(self::class, 'ticket_status_flow', 'from_status_id', 'to_status_id')
                    ->using(TicketStatusFlow::class)
                    ->withTimestamps();
    }

    /**
     * Returns an array of status that is mapped as the previous status.
     */
    public function prev_status() {
        return $this->belongsToMany(self::class, 'ticket_status_flow', 'to_status_id', 'from_status_id')
                    ->using(TicketStatusFlow::class)
                    ->withTimestamps();
    }

    public function tickets() {
       return $this->hasMany(Ticket::class, 'current_status_id', 'id');
    }
}
