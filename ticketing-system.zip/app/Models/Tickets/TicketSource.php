<?php

namespace App\Models\Tickets;

use App\Models\Tickets\Ticket;
use App\Models\ModelBase;

/**
 * Represents a ticket source.
 */
class TicketSource extends ModelBase
{
    protected $fillable = [ 'name' ];

    /**
     * The tickets with the current source.
     */
    public function tickets() {
        return $this->hasMany(Ticket::class);
    }
}
