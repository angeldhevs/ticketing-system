<?php

namespace App\Models\Tickets;

use App\Models\Tickets\Ticket;
use App\Models\Tickets\TicketStatus;
use App\Models\Admin\Manage\User;
use App\Models\ModelBase;

/**
 * Represents a progress of a ticket.
 */
class TicketProgress extends ModelBase
{
    protected $table = 'ticket_progress';
    public $incrementing = true;

    protected $fillable = [
        'ticket_id',
        'status_id',
        'asignee_id',
        'reporter_id',
        'remarks',
    ];

    /**
     * The ticket where this progress is associated to.
     */
    public function ticket() {
        return $this->belongsTo(Ticket::class, 'ticket_id', 'id');
    }

    /**
     * The ticket status for the current progress.
     */
    public function status() {
        return $this->belongsTo(TicketStatus::class, 'status_id', 'id');
    }

    /**
     * The user (presumably with a role of agent) to whose the ticket is assigned to.
     */
    public function asignee() {
        return $this->belongsTo(User::class, 'asignee_id', 'id');
    }

    /**
     * The user (presumably with a role of admin/team leader) to assigned the ticket to the agent.
     */
    public function reporter() {
        return $this->belongsTo(User::class, 'reporter_id', 'id');
    }
}
