<?php

namespace App\Models\Tickets;

use App\Models\ModelBase;
use Nexmo\User\User;
use App\Models\Core\Ticket;

/**
 * The comments related to a ticket.
 */
class TicketComment extends ModelBase
{
    protected $fillable = [
        'comment',
        'ticket_id',
        'parent_comment_id',
        'user_id'
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * The ticket where this comment is associated to.
     */
    public function ticket() {
        return $this->belongsTo(Ticket::class);
    }

    /**
     * The parent comment.
     */
    public function parent() {
        return $this->belongsTo(this::class, 'parent_comment_id');
    }

    /**
     * The related children comments.
     */
    public function children() {
        return $this->hasMany(this::class, 'id', 'parent_comment_id');
    }

    /**
     * The user who adds the comment.
     */
    public function user() {
        return $this->belongsTo(User::class);
    }
}
