<?php

namespace App\Models\Tickets;

use App\Models\ModelBase;
use App\Models\Tickets\TicketSource;
use App\Models\Tickets\TicketSeverity;
use App\Models\Tickets\TicketProgress;
use Illuminate\Http\Request;

/**
 * Represents the ticket to be processed by an agent.
 */
class Ticket extends ModelBase
{
    protected $fillable = [
        'ticket_number',
        'title',
        'client_name',
        'client_email',
        'details',
        'source_id',
        'severity_id',
        'current_status_id'
    ];

    /**
     * The source of the ticket - either from email or from team leader.
     */
    public function source() {
        return $this->belongsTo(TicketSource::class);
    }

    /**
     * The severity of the ticket - either low, medium, high, critical, or unclassified.
     */
    public function severity() {
        return $this->belongsTo(TicketSeverity::class);
    }

    
    /**
     * The current status of the ticket.
     */
    public function status() {
        return $this->belongsTo(TicketStatus::class, 'current_status_id', 'id');
    }


    /**
     * The progress of the ticket. This strictly points to the ticket status changes and not the changes on the ticket (e.g. change title).
     */
    public function progress() {
        return $this->hasMany(TicketProgress::class)->orderBy('created_at', 'desc');
    }

    /**
     * The comments associated with the current ticket.
     */
    public function comments() {
        return $this->hasMany(TicketComment::class);
    }

    /**
     * Returns the latest progress of the ticket.
     */
    public function current() {
        return $this->hasOne(TicketProgress::class, 'ticket_id', 'id')
                    ->orderBy('created_at', 'desc')
                    ->first();
    }

    /**
     * Returns if the current ticket has any progress recorded.
     */
    public function hasProgress() {
        return $this->current() !== null;
    }

    /**
     * Returns true if the ticket is closed; otherwise false.
     */
    public function isClosed() {
        return strcasecmp($this->current()->status->name, "closed") == 0;
    }


    public function countClosed()
    {
        return $this->current()->count();
    }

    public static function fromRequest(Request $request)
    {
        $instance = parent::fromRequest($request);
    }
}
