<div 
  class="form-group <?php echo e($wrapper['class'] ?? ""); ?>" >
  <label for="<?php echo e($select['name']); ?>" class="<?php echo e($label['class'] ?? ""); ?>"><?php echo e($label['text'] ?? $select['name']); ?></label>
  <div class="<?php echo e($select['wrapperClass'] ?? ""); ?>" >
    <select
      id="<?php echo e($select['id'] ?? $select['name']); ?>"
      class="form-control <?php echo e($select['class'] ?? ""); ?>"
      name="<?php echo e($select['name'] ?? ""); ?>" >
      <?php if(isset($select['default_option'])): ?>
      <option value="" disable selected><?php echo e($select['default_option'] ?? "Select..."); ?></option>
      <?php endif; ?>
      <?php $__currentLoopData = $select['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($option[$select['option_value']]); ?>"><?php echo e($option[$select['option_text']]); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </div>
</div>