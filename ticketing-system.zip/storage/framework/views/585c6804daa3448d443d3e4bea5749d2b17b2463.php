<?php
  $hasWrappers = isset($wrappers);
  $hasOuterWrapper = $hasWrappers && isset($wrappers['outer']) && is_array($wrappers['outer']);
  $hasInnerWrapper = $hasWrappers && isset($wrappers['inner']) && is_array($wrappers['inner']);
  $hasLabel = isset($label) && is_array($label);
  $hasPrepend = isset($pre) && is_array($pre);
  $hasError = isset($error) && is_array($error);
?>

<?php if($hasOuterWrapper): ?>
<?php ($outerWrap = $wrappers['outer']); ?>
<div class="<?php echo e($outerWrap['class'] ?? 'form-group'); ?>" 
  <?php echo $__env->make('components.utils.attr', [ 'src' => $outerWrap, 'name' => 'attr' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.utils.attr', [ 'src' => $outerWrap, 'name' => 'data' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>>
<?php endif; ?>

  
  <?php if($hasLabel): ?>
  <label for="<?php echo e($name); ?>" 
    class="<?php echo e($label['class'] ?? ''); ?>"
    <?php echo $__env->make('components.utils.attr', [ 'src' => $label, 'name' => 'attr' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <?php echo $__env->make('components.utils.attr', [ 'src' => $label, 'name' => 'data' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>>
    <?php if(isset($label['html']) && is_string($label['html'])): ?>
      <?php echo $label['html']; ?>

    <?php else: ?>
      <?php echo e($label['text']); ?>

    <?php endif; ?>
  </label>
  <?php endif; ?>

  
  <?php if($hasInnerWrapper): ?>
  <?php ($innerWrap = $wrappers['inner']); ?>
  <div class="<?php echo e($innerWrap['class'] ?? ''); ?>" 
    <?php echo $__env->make('components.utils.attr', [ 'src' => $innerWrap, 'name' => 'attr' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('components.utils.attr', [ 'src' => $innerWrap, 'name' => 'data' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>>
  <?php endif; ?>

  
  <?php if($hasPrepend): ?>
  <<?php echo e($pre['tag'] ?? 'div'); ?> 
    class="input-group-prepend <?php echo e($pre['class'] ?? ''); ?>"
    <?php echo $__env->make('components.utils.attr', [ 'src' => $pre, 'name' => 'attr' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('components.utils.attr', [ 'src' => $pre, 'name' => 'data' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>>
    <div class="input-group-text">
      <?php if(isset($pre['html']) && is_string($pre['html'])): ?>
        <?php echo $pre['html']; ?>

      <?php else: ?>
        <?php echo e($pre['text']); ?>

      <?php endif; ?>
    </div>
  </<?php echo e($pre['tag'] ?? 'div'); ?>>
  <?php endif; ?>
  
    
      <input 
        type="<?php echo e($type ?? 'text'); ?>" 
        id="<?php echo e($id ?? ''); ?>"
        class="form-control <?php echo e($class ?? ''); ?>"
        name="<?php echo e($name ?? ''); ?>"
        value="<?php echo e($value ?? ''); ?>"
        placeholder="<?php echo e($placeholder ?? null); ?>"
        <?php echo $__env->renderWhen(isset($attr),'components.utils.attr', [ 'src' => [ 'attr' => $attr ?? null ], 'name' => 'attr' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path'))); ?> 
        <?php echo $__env->renderWhen(isset($data),'components.utils.attr', [ 'src' => [ 'data' => $data ?? null ], 'name' => 'data' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path'))); ?> 
        <?php echo $__env->renderWhen(isset($validation),'components.utils.attr', [ 'src' => [ 'validation' => $validation ?? null ], 'name' => 'validation', 'prefix' => 'data-validation' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path'))); ?> 
        />

      <?php if($hasError): ?>
      <<?php echo e($error['tag'] ?? 'span'); ?> 
        <?php if(isset($error['class'])): ?> class="<?php echo e($error['class']); ?>"<?php endif; ?>
        <?php echo $__env->make('components.utils.attr', [ 'src' => $error, 'name' => 'attr' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('components.utils.attr', [ 'src' => $error, 'name' => 'data' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>>
        <?php if(isset($error['html'])): ?>
          <?php echo $error['html']; ?>

        <?php else: ?>
          <?php echo e($error['text']); ?>

        <?php endif; ?>
      </<?php echo e($error['tag'] ?? "span"); ?>>
      <?php endif; ?> 

  
  <?php if($hasInnerWrapper): ?>
  </div>
  <?php endif; ?>

<?php if($hasOuterWrapper): ?>
</div>
<?php endif; ?>