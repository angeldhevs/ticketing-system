<?php
$status_context = ['danger', 'secondary', 'primary', 'info', 'warning', 'success'];
$severity_context = ['secondary', 'info', 'primary', 'warning', 'danger'];
$severity_color = $severity_context[$ticket->severity->id - 1];
$status_color = $status_context[$ticket->status->id - 1];
?>



<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
  <div class="row p-1">
    <div class="col col-sm-12 col-md-6">
      <?php echo $__env->make('components.display-field', [
        'wrapper' => [ 'class' => 'text-muted' ],
        'label' => [ 'name' => 'Source' ],
        'value' => [ 'val' => $ticket->source->name ]
      ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col col-sm-12 col-md-6">
      <?php echo $__env->make('components.display-field', [
        'wrapper' => [ 'class' => 'text-muted' ],
        'label' => [ 'name' => 'Created' ],
        'value' => [ 'val' => $ticket->created_at->diffForHumans() ]
      ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
  <div class="row p-1">
    <div class="col col-sm-12 col-md-6">
      <?php echo $__env->make('components.display-field', [
        'wrapper' => [ 'class' => 'text-muted' ],
        'label' => [ 'name' => 'Assignee' ],
        'value' => [ 'val' => $ticket->current() != null ? $ticket->current()->asignee->name : '- Not assigned -' ]
      ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col col-sm-12 col-md-6">
      <?php echo $__env->make('components.display-field', [
        'wrapper' => [ 'class' => 'text-muted' ],
        'label' => [ 'name' => 'Assigned by' ],
        'value' => [ 'val' => $ticket->current() != null ? $ticket->current()->reporter->name : '- Not assigned -' ]
      ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
  <div class="row p-1">
    <div class="col col-sm-12 col-md-6">
      <?php echo $__env->make('components.display-field', [
        'wrapper' => [ 'class' => 'text-muted' ],
        'label' => [ 'name' => 'Severity' ],
        'value' => [
          'val' => '
            <span class="p-2 badge badge-'.$severity_color.'">'
              .$ticket->severity->name ?? '- Not set -'.
            '</span>',
          'is_html' => true
        ]
      ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col col-sm-12 col-md-6">
      <?php echo $__env->make('components.display-field', [
        'wrapper' => [ 'class' => 'text-muted' ],
        'label' => [ 'name' => 'Status' ],
        'value' => [
          'val' => '
            <span class="p-2 badge badge-'.$status_color.'">'
              .($ticket->current() == null ? 'New' : $ticket->status->name).
            '</span>',
          'is_html' => true
        ]
      ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
  <div class="row p-1">
    <div class="form-group col-sm-12 text-muted">
      <strong>Details : </strong>
      <textarea id="ticket_details" class="form-control disabled" name="ticket_severity" rows="5" disabled="disabled"><?php echo e($ticket->details); ?></textarea>
    </div>
  </div>
  <?php echo $__env->make('tickets.history', [ 'ticket_progress' => $ticket->progress ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<?php echo $__env->make('tickets.edit', [ 'ticket_status' => $ticket_status ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php if(Auth::user()->has_role('admin') && $ticket->current() == null): ?>
<?php echo $__env->make('tickets.assign', [ 'agents' => $agents ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/modules/tickets.js')); ?>" ></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/ticket/view.css')); ?>"></link>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
  'pageTitle' => 'Ticket '.$ticket->ticket_number,
  'header' => [
    'html' =>
    '<strong class="badge badge-'.$severity_color.'">
      <i class="fa fa-ticket-alt"></i>'
      .$ticket->ticket_number.
    '</strong>'
      .$ticket->title,
    'buttons' => [
      'edit' => [
        'toggle' => 'modal',
        'target' => '#modalUpdateTicket',
        'icon' => 'fa-edit',
        'includeIf' => Auth::user()->has_role('agent') && $ticket->current()->status->name <> "Closed"
      ]
    ]
  ]
], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>