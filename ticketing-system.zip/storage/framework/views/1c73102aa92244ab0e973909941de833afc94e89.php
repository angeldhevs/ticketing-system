<nav id="sidebar-left" class="sidebar sidebar-dark shadow accordion">
  <div class="sidebar-header text-center">
    <span class="app-name">
        <?php echo e(config('app.name')); ?>

    </span>
  </div>
  <?php if(Auth::user()->has_role('admin')): ?>
    <?php echo $__env->make('shared.menu.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php elseif(Auth::user()->has_role('team leader')): ?>
    <?php echo $__env->make('shared.menu.team-leader', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php elseif(Auth::user()->has_role('agent')): ?>
    <?php echo $__env->make('shared.menu.agent', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php endif; ?>
  <ul class="nav flex-column sticky-bottom">
    <li class="nav-item">
      <a class="nav-link" href="#">
        <i class="fa fa-tools" aria-hidden="true"></i> <span>Settings</span>
      </a>
    </li>
  </ul>
</nav>