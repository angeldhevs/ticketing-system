<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
  <div class="col-md-8">
    <div class="card">
      <div class="card-body">
        <h3 class="card-title text-center">
          <i class="fa fa-sign-in-alt"></i>
          <?php echo e(__('Login')); ?>

        </h3>
        <hr />
        <form method="POST" action="<?php echo e(route('login')); ?>">
          <?php echo csrf_field(); ?>
          <?php echo $__env->make('components.input', [
            'id' => 'email',
            'type' => 'email',
            'name' => 'email',
            'placeholder' => 'Email address',
            'class' => $errors->has('email') ? ' is-invalid' : '',
            'value' => old('email'),
            'attr' => [ 'required', 'autofocus' ],
            'wrappers' => [ 
              'outer' => [ 'class' => 'form-group row' ],
              'inner' => [ 'class' => 'input-group col-sm-10 offset-sm-1 col-md-8 offset-md-2 col-lg-6 offset-lg-3' ]
            ],
            'pre' => [ 'html' => '<i class="fa fa-at"></i>' ],
            'error' => [
              'class' => 'invalid-feedback',
              'html' => '<strong>'.$errors->first('email').'</strong>'
            ]
          ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('components.input', [
            'id' => 'password',
            'type' => 'password',
            'name' => 'password',
            'placeholder' => 'Password',
            'class' => $errors->has('password') ? ' is-invalid' : '',
            'value' => old('password'),
            'attr' => [ 'required' ],
            'wrappers' => [ 
              'outer' => [ 'class' => 'form-group row' ],
              'inner' => [ 'class' => 'input-group col-sm-10 offset-sm-1 col-md-8 offset-md-2 col-lg-6 offset-lg-3' ]
            ],
            'pre' => [ 'html' => '<i class="fa fa-asterisk"></i>' ],
            'error' => [
              'class' => 'invalid-feedback',
              'html' => '<strong>'.$errors->first('password').'</strong>'
            ]
          ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="form-group row">
            <div class="col-md-6 offset-md-4">
              <?php echo $__env->make('components.checkbox', [
                'id' => 'remember',
                'name' => 'remember',
                'checked' => old('remember'),
                'label' => __('Remember Me')
              ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
          </div>
          <div class="form-group row mb-0">
            <div class="col-md-8 offset-md-4">
              <button type="submit" class="btn btn-primary">
                <?php echo e(__('Login')); ?>

              </button>

              <?php if(Route::has('password.request')): ?>
                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                  <?php echo e(__('Forgot Your Password?')); ?>

                </a>
              <?php endif; ?>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/components/checkbox.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/auth/login.css')); ?>">
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [ 
    'bodyClass' => 'login-form',
    'wrapperClass' => 'container'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>