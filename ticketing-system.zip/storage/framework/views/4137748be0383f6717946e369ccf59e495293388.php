<div id="recent-ticket-updates" class="grid-stack-item card" data-gs-x="0" data-gs-y="0" data-gs-width="4" data-gs-height="5" data-source="<?php echo e(route('api.dashboard.recent-ticket-updates')); ?>">
  
    <div class="card-body p-2">
      <h6 class="card-title">Ticket Updates</h6>
      <table>
        <thead>
          <th>Ticket #</th>
          <th>Severity</th>
          <th>Status</th>
          <th>Assignee</th>
        </thead>
        <tbody>
        </tbody>
      </table>
    </div>
  
</div>