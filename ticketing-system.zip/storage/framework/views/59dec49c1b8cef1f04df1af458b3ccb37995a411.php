<div id="ticket-form" class="modal fade"  tabindex="-1" role="dialog" aria-labelledby="ticketForm" aria-hidden="true">
	<form action="<?php echo e($action ?? "/tickets"); ?> " method="POST" class="modal-dialog modal-lg modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Create Ticket</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
		<div>
		<div class="modal-body">
			<?php echo $__env->make('components.input', [ 
				'name' => 'ticket_title', 
				'placeholder' => 'Title',
				'label' => [ 
					'text' => 'Title', 
					'class' => 'col-sm-12 col-md-1 col-form-label' 
				],
				'wrappers' => [ 
					'outer' => [ 'class' => 'form-group row' ],
					'inner' => [ 'class' => 'col-sm-12 col-md-11' ],
				]
			], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="row">
				<div class="col col-sm-12 col-md-6">
					<?php echo $__env->make('components.input', [ 
						'name' => 'client_name', 
						'placeholder' => 'Client name',
						'label' => [ 
							'text' => 'Client', 
							'class' => 'col-sm-12 col-md-2 col-form-label' 
						],
						'wrappers' => [ 
							'outer' => [ 'class' => 'form-group row' ],
							'inner' => [ 'class' => 'col-sm-12 col-md-10' ],
						]
					], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
				<div class="col col-sm-12 col-md-6">
					<?php echo $__env->make('components.input', [ 
						'name' => 'client_email', 
						'wrapperClass' => 'col-sm-12 col-md-10', 
						'type' => 'text', 
						'placeholder' => 'Email address',
						'label' => [ 
							'text' => 'Email', 
							'class' => 'col-sm-12 col-md-2 col-form-label' 
						],
						'wrappers' => [
							'outer' => [ 'class' => 'form-group row' ],
							'inner' => [ 'class' => 'col-sm-12 col-md-10' ],
						] 
					], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
			<div class="row">
				<div class="col col-sm-12 col-md-6">
					<?php echo $__env->make('components.select', [ 
						'name' => 'severity_id', 
						'options' => $severities, 
						'optionValue' => 'id', 
						'optionText' => 'name',
						'label' => [ 
							'text' => 'Severity', 
							'class' => 'col-sm-12 col-md-2 col-form-label'
						],
						'wrappers' => [
							'outer' => [ 'class' => 'form-group row' ],
							'inner' => [ 'class' => 'col-sm-12 col-md-10' ]
						],
						'defaultOption' => [ 'text' => 'Select...' ]
					], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
				<div class="col col-sm-12 col-md-6">
					<?php echo $__env->make('components.select', [ 
						'name' => 'agent_id', 
						'options' => $agents, 
						'optionValue' => 'id',
						'optionText' => 'name',
						'label' => [ 
							'text' => 'Agent', 
							'class' => 'col-sm-12 col-md-2 col-form-label'
						],
						'wrappers' => [
							'outer' => [ 'class' => 'form-group row' ],
							'inner' => [ 'class' => 'col-sm-12 col-md-10' ]
						],
						'defaultOption' => [ 'text' => 'Select...' ]
					], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
			</div>
			<div class="form-group">
				<label for="ticket_details">Details</label>
				<textarea class="form-control" id="ticket_details" name="ticket_details" rows="3"></textarea>
			</div>
		</div>
		<div class="modal-footer">
			<button type="submit" class="btn btn-primary" id="btnSubmitTicket">Submit</button>
			<button type="reset" class="btn btn-secondary" data-dismiss="modal">Clear</button>
		</div>
		</div>
	</form>
</div>