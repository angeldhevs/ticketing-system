<?php $__env->startSection('content'); ?>
<h2>
    <i class="fa fa-user-plus"></i> Create Account
</h2>
<hr />
<div class="row">
    <div class="col col-sm-12 col-md-6">
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('components.input', [ 
                'name' => 'name', 
                'placeholder' => 'Enter '.__('Name'),
                'value' => old('name'),
                'class' => $errors->has('name') ? ' is-invalid' : '',
                'attr' => [ 
                    'required', 
                    'autofocus',
                    'autocomplete' => 'off' 
                ],
                'label' => [ 
                    'text' => __('Name'), 
                    'class' => 'col-md-4 col-form-label text-md-right' 
                ],
                'wrappers' => [ 
                    'outer' => [ 'class' => 'form-group row' ],
                    'inner' => [ 'class' => 'col-sm-12 col-md-8' ]
                ],
                'error' => [
                    'tag' => 'small',
                    'html' => '<strong>'.$errors->first('name').'</strong>'
                ]
            ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('components.input', [ 
                'name' => 'email', 
                'type' => 'email', 
                'placeholder' => 'Enter '.__('E-Mail Address'),
                'value' => old('email'),
                'class' => $errors->has('email') ? ' is-invalid' : '',
                'attr' => [ 
                    'required', 
                    'autocomplete' => 'off' 
                ],
                'label' => [ 
                    'text' => __('E-Mail Address'), 
                    'class' => 'col-md-4 col-form-label text-md-right' 
                ],
                'wrappers' => [ 
                    'outer' => [ 'class' => 'form-group row' ],
                    'inner' => [ 'class' => 'col-sm-12 col-md-8' ]
                ],
                'error' => [
                    'tag' => 'small',
                    'html' => '<strong>'.$errors->first('email').'</strong>'
                ]
            ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('components.select', [ 
                'name' => 'role_id', 
                'options' => $roles, 
                'optionValue' => 'id',
                'optionText' => 'name',
                'label' => [ 
                    'text' => 'Role', 
                    'class' => 'col-md-4 col-form-label text-md-right'
                ],
                'wrappers' => [
                    'outer' => [ 'class' => 'form-group row' ],
                    'inner' => [ 'class' => 'col-sm-12 col-md-8' ]
                ],
                'defaultOption' => [ 'text' => 'Select...' ]
            ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('components.input', [ 
                'name' => 'password', 
                'placeholder' => __('Password'),
                'value' => 'P@ssw0rd01',
                'class' => 'disabled',
                'attr' => [ 'disabled' ],
                'label' => [ 
                    'text' => __('Password'), 
                    'class' => 'col-md-4 col-form-label text-md-right' 
                ],
                'wrappers' => [ 
                    'outer' => [ 'class' => 'form-group row' ],
                    'inner' => [ 'class' => 'col-sm-12 col-md-8' ]
                ],
                'error' => [
                    'tag' => 'small',
                    'html' => '<strong>This wil be the default password.</strong>'
                ]
            ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="form-group row mb-0">
                <div class="col-md-6 offset-md-4">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Register')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Create Account',
    'bodyClass' => 'create-account',
    'wrapperClass' => 'container mt-4'
], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>