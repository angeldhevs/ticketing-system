<?php
  $hasSrc = isset($src) && is_array($src);
  $hasName = isset($name) && is_string($name);
  $hasPrefix = isset($prefix) && is_string($prefix);
  $elements = $hasSrc ? ($hasName && array_key_exists($name, $src) && is_array($src[$name]) ? $src[$name] : null) : null;
  $hasElements = $elements !== null;
?>

<?php if($hasSrc && $hasElements): ?>
  <?php $__currentLoopData = array_keys($elements); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(is_numeric($key)): ?>
      <?php echo e($elements[$key]); ?>

    <?php elseif($hasPrefix): ?>
      <?php echo e($prefix.'-'.$key); ?>="<?php echo e($elements[$key]); ?>"
    <?php elseif($hasName && $name !== 'attr'): ?>
      <?php echo e($name.'-'.$key); ?>="<?php echo e($elements[$key]); ?>"
    <?php else: ?>
    <?php echo e($key); ?>="<?php echo e($elements[$key]); ?>"
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

