<label class="custom-checkbox"
  <?php if(isset($wrapper)): ?>
  <?php echo $__env->make('components.utils.attr', [ 'src' => $wrapper, 'name' => 'attr'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.utils.attr', [ 'src' => $wrapper, 'name' => 'data'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php endif; ?>
  >
  <input type="checkbox"
    <?php echo isset($id) ? 'id='.$id.' ' : ''; ?>

    <?php echo isset($name) ? 'name='.$name.' ' : ''; ?>

    <?php echo isset($checked) && $checked ? 'checked' : ''; ?>

    <?php echo $__env->renderWhen(isset($attr), 'components.utils.attr', [ 'src' => $attr ?? null ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path'))); ?>
    <?php echo $__env->renderWhen(isset($data), 'components.utils.attr', [ 'src' => $data ?? null, 'prefix' => 'data'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path'))); ?>>
  <span class="check-mark"></span>
  <span class="checkbox-label"><?php echo e($label); ?></span>
</label>