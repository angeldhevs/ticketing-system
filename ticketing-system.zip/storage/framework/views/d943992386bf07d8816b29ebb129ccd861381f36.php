<nav id="sidebar-left" class="sidebar">
  <div class="sidebar-header">
    Ticketing System
  </div>
  <ul class="nav flex-column">
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
        <i class="fa fa-tachometer-alt" aria-hidden="true"></i> Dashboard
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="/reports">
        <i class="fa fa-chart-bar" aria-hidden="true"></i> Reports
      </a>
    </li>
    <?php if(Auth::user()->has_role('admin')): ?>
    <li class="nav-item">
      <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user" aria-hidden="true"></i> Account</a>
      <ul class="collapse list-unstyled" id="pageSubmenu">
          <li>
              <a href="/list">List Account</a>
          </li>
          <li>
              <a href="/accounts">Add Account</a>
          </li>
      </ul>
  </li>
    <?php endif; ?>
 
  </ul>
</nav>