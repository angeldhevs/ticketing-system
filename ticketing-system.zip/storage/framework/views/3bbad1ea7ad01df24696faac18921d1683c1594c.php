<div class="mdl-textfield mdl-js-textfield <?php echo e($wrapperClass ?? ""); ?>">
  <input type="<?php echo e($inputType ?? "text"); ?>" 
    <?php if(isset($id)): ?> id="<?php echo e($id); ?>" <?php endif; ?>
    <?php if(isset($name)): ?> name="<?php echo e($name); ?>" <?php endif; ?>
    <?php if(isset($value)): ?> value="<?php echo e($value); ?>" <?php endif; ?>
    <?php if(isset($attrs)): ?>
      <?php if(is_array ($attrs)): ?>
        <?php $__currentLoopData = $attrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e(key($attr)); ?>=<?php echo e($attr); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          
      <?php endif; ?>
    <?php endif; ?>
    class="mdl-textfield__input <?php echo e($class ?? ""); ?>">
  <label for="<?php echo e($name); ?>" class="mdl-textfield__label <?php echo e($labelClass ?? ""); ?>"><?php echo e($label); ?></label>
</div>