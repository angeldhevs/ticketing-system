<ul class="nav flex-column">
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
      <i class="fa fa-tachometer-alt" aria-hidden="true"></i> Dashboard
    </a>
  </li>
</ul>