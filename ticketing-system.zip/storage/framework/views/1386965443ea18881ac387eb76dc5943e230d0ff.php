<div id="ticket-progress">
  <?php if($ticket_progress->count() > 0): ?>
  <div class="row p-1">
    <div class="form-group col-sm-12 text-muted">
      <strong>History: </strong>
        <ul class="list-group">
        <?php $__currentLoopData = $ticket_progress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $progress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php ($status = $progress->status); ?>
          <li class="list-group-item list-group-item-<?php echo e($status_context[$status->id - 1]); ?>">
            <div class="d-flex w-100 justify-content-between align-items-center">
              <h6 class="mb-1">
                <strong>
                  <?php switch($status->name):
                  case ("New"): ?>
                    Ticket added to system.
                    <?php break; ?>
                    <?php case ("Open"): ?>
                      Ticket assigned to <?php echo e($progress->asignee->name); ?> by <?php echo e($progress->reporter->name); ?>.
                      <?php break; ?>
                    <?php case ("In Progress"): ?>
                      Ticket is in progress.
                      <?php break; ?>
                    <?php case ("Needs More Info"): ?>
                      Ticket needs more information.
                      <?php break; ?>
                    <?php case ("Resolved"): ?>
                      Ticket marked as resolved.
                      <?php break; ?>
                    <?php case ("Closed"): ?>
                      Ticket marked as closed.
                      <?php break; ?>
                    <?php default: ?>
                  <?php endswitch; ?>
                </strong>
              </h6>
            <span class="badge badge-<?php echo e($status_context[$status->id - 1]); ?>"><?php echo e($status->name); ?></span>
          </div>
          <div class="d-flex w-100 justify-content-between align-items-center">
            <span class="text-muted"><?php echo e($progress->remarks); ?></span>
            <span class="pull-right"><?php echo e($progress->created_at->diffForHumans()); ?></span>
          </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
</div>
<?php endif; ?>
</div>
