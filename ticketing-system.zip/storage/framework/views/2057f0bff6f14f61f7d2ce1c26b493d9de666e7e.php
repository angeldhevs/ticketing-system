<div 
  class="<?php echo e($wrapper['class'] ?? 'form-group'); ?>" 
  <?php echo $__env->make('components.attr', [ 'src' => $wrapper, 'name' => 'attr' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
  <?php echo $__env->make('components.attr', [ 'src' => $wrapper, 'name' => 'data', 'prefix' => 'data' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>>

  
  <?php if(isset($label) && is_array($label)): ?>
  <label for="<?php echo e($input['name']); ?>" 
    class="<?php echo e($label['class'] ?? ''); ?>"
    <?php echo $__env->make('components.attr', [ 'src' => $label, 'name' => 'attr' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <?php echo $__env->make('components.attr', [ 'src' => $label, 'name' => 'data', 'prefix' => 'data' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>>
    <?php if(isset($label['html']) && is_string($label['html'])): ?>
      <?php echo $label['html']; ?>

    <?php else: ?>
      <?php echo e($label['text']); ?>

    <?php endif; ?>
  </label>
  <?php endif; ?>

  
  <?php if(isset($input['wrapper']) && is_array($input['wrapper'])): ?>
  <div class="<?php echo e($input['wrapper']['class'] ?? ''); ?>" 
  <?php echo $__env->make('components.attr', [ 'src' => $input['wrapper'], 'name' => 'attr' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
  <?php echo $__env->make('components.attr', [ 'src' => $input['wrapper'], 'name' => 'data', 'prefix' => 'data' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>>
  <?php endif; ?>

  
  <?php if(isset($pre) && is_array($pre)): ?>
  <<?php echo e($pre['tag'] ?? 'div'); ?> 
    class="input-group-prepend <?php echo e($pre['class'] ?? ''); ?>"
    <?php echo $__env->make('components.attr', [ 'src' => $pre, 'name' => 'attr' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <?php echo $__env->make('components.attr', [ 'src' => $pre, 'name' => 'data', 'prefix' => 'data' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> >
    <?php if(isset($pre['html']) && is_string($pre['html'])): ?>
      <?php echo $pre['html']; ?>

    <?php else: ?>
      <div class="input-group-text">
        <?php echo e($pre['text']); ?>

      </div>
    <?php endif; ?>
  </<?php echo e($pre['tag'] ?? 'div'); ?>>
  <?php endif; ?>
  
    
    <input 
      type="<?php echo e($input['type'] ?? "text"); ?>" 
      id="<?php echo e($input['id'] ?? $input['name']); ?>"
      class="form-control <?php echo e($input['class'] ?? ''); ?>"
      name="<?php echo e($input['name'] ?? ''); ?>"
      value="<?php echo e($input['value'] ?? null); ?>"
      placeholder="<?php echo e($input['placeholder'] ?? null); ?>"
      <?php echo $__env->make('components.attr', [ 'src' => $input, 'name' => 'attr' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
      <?php echo $__env->make('components.attr', [ 'src' => $input, 'name' => 'data', 'prefix' => 'data' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>>

    <?php if(isset($input['error']) && is_array($input['error'])): ?>
    <<?php echo e($input['error']['tag'] ?? "span"); ?> 
      <?php if(isset($input['error']['class'])): ?>
      class="<?php echo e($input['error']['class']); ?>"
      <?php endif; ?>
      <?php echo $__env->make('components.attr', [ 'src' => $input['error'], 'name' => 'attr' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
      <?php echo $__env->make('components.attr', [ 'src' => $input['error'], 'name' => 'data', 'prefix' => 'data' ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>>
      <?php if(isset($input['error']['html'])): ?>
        <?php echo $input['error']['html']; ?>

      <?php else: ?>
        <?php echo e($input['error']['text']); ?>

      <?php endif; ?>
    </<?php echo e($input['error']['tag'] ?? "span"); ?>>
    <?php endif; ?>    

  
  <?php if(isset($input['wrapper']) && is_array($input['wrapper'])): ?>
  </div>
  <?php endif; ?>
</div>