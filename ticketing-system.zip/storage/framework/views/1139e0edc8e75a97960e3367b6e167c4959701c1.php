<?php if(Session::has('alert')): ?>
  $alert = <?php echo e(Session::get('alert')); ?>

  dd($alert);
  //If status is set, show a toast notification.
  <script type="text/javascript">
    $(function() {
      let alert = <?php echo json_encode($alert); ?>

      console.log(alert);
      toastr[alert.type](alert.message);
    });
  </script>
<?php endif; ?>