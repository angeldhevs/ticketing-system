<?php $__env->startSection('content'); ?>
<div id="admin-dashboard" class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#create-ticket-modal">
                        <i class="fas fa-plus"></i> Create Ticket
                    </button>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table id="tickets" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>Ticket ID</th>
                                <th>Title</th>
                                <th>Severity</th>
                                <th>Date Created</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="/tickets/<?php echo e($ticket->id); ?>">
                                        <?php echo e($ticket->ticket_number); ?>

                                    </a>
                                </td>
                                <td><?php echo e($ticket->title); ?></td>
                                <td><?php echo e($ticket->severity->name); ?></td>
                                <td><?php echo e($ticket->created_at); ?></td>
                                <td>
                                    <a href="/tickets/<?php echo e($ticket->id); ?>" class="btn btn-sm btn-primary"  >
                                        <i class="glyphicon glyphicon-pencil"></i>
                                        View
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('ticket.create', ['severities' => $severities, 'source' => $source], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="/js/admin/dashboard.js" ></script>
    <script type="text/javascript" src="/js/ticket/create.js" ></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', [ 'title' => 'Admin Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>