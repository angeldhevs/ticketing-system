<?php
$is_admin = Auth::user()->has_role('admin');
?>



<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="dt-wrapper">
    <div class="dt-top-bar row">
      <div class="col col-sm-12 col-md-4 order-xs-last">
        <div class="input-group mb-2">
            <div class="input-group-prepend">
              <div class="input-group-text">
                <i class="fa fa-search"></i>
              </div>
            </div>
            <input type="search" name="searh" class="form-control form-control-sm col-10" aria-controls="tickets" placeholder="Search here" />
        </div>
      </div>
      <div class="col col-sm-12 col-md-8 order-xs-first text-right">
        <div class="button-group" role="group">
          <?php if($is_admin): ?>
          <span data-toggle="tooltip" data-placement="right" title="New Ticket">
            <button type="button" class="btn btn-light border fa fa-plus"  data-toggle="modal" data-target="#ticket-form" ></button>
          </span>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <table class="table table-striped table-hover" style="width:100%" data-source="<?php echo e(route('api.tickets.index')); ?>">
        <thead>
            <tr>
                <th>Ticket #</th>
                <th>Title</th>
                <th>Severity</th>
                <th>Status</th>
                <th>Last Update</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        
        </tbody>
    </table>
  </div>
</div>
<?php if($is_admin): ?>
<?php echo $__env->make('tickets.create', $createTicket, \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/modules/tickets.js')); ?>" ></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
  'pageTitle' => 'Tickets',
  'header' => [
    'icon' => 'fa-ticket-alt',
    'text' => $is_admin ? 'All Tickets' : 'My Tickets'
  ]
], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>