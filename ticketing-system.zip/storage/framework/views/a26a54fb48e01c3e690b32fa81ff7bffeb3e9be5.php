<nav class="navbar navbar-expand-md navbar-inverse navbar-laravel fixed-top flex-md-nowrap p-0">
  <a class="navbar-brand col-sm-3 col-md-2 py-3 px-2 m-0" href="<?php echo e(route('dashboard')); ?>"><?php echo e(config('app.name')); ?></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
      <span class="fa fa-caret-down"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <?php if(auth()->guard()->guest()): ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
        </li>
        <?php else: ?>
        <li class="nav-item dropdown">
          <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
            Hi, <?php echo e(Auth::user()->name); ?> <i class="fa fa-caret"></i>
          </a>

          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
              onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
            </form>
          </div>
        </li>
      <?php endif; ?>
    </ul>
  </div>
</nav>