<nav id="sidebar">
    <div class="sidebar-header">
        Ticketing System
    </div>

    <ul class="list-unstyled components">
        <li>
            <a href="/dashboard"><i class="fas fa-columns" aria-hidden="true"></i> Dashboard</a>
        </li>
        <li>
            <a href="/reports"><i class="fas fa-clipboard" aria-hidden="true"></i> Reports</a>
        </li>
        <li>
            <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-user" aria-hidden="true"></i> Account</a>
            <ul class="collapse list-unstyled" id="pageSubmenu">
                <li>
                    <a href="/list">List Account</a>
                </li>
                <li>
                    <a href="/accounts">Add Account</a>
                </li>
            </ul>
        </li>

    </ul>

</nav>