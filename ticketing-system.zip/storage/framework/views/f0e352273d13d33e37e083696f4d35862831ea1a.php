<?php
$path = trim(Request::path(), '/');
$segments = explode('/', $path);
$buttons = isset($buttons) && is_array($buttons) ? $buttons : null;
$defaultHeaderTextTag = 'span';
?>

<main class="main-content <?php if(isset($wrapperClass)): ?> <?php echo e($wrapperClass); ?> <?php endif; ?>"
  <?php if(isset($wrapperId)): ?> id="<?php echo e($wrapperId); ?>" <?php endif; ?>>

  <!-- Page Header -->
  <div class="header-bar">
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="/">
          <i class="fa fa-home"></i>
        </a>
      </li>
      <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="breadcrumb-item <?php if($loop->last): ?> active <?php endif; ?>"><?php echo e($segment); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>

    <?php if(isset($include)): ?>
    <?php echo $__env->make('include', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif($buttons !== null): ?>
    <div class="header-buttons btn-group">
      <?php $__currentLoopData = $buttons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $button): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!isset($button['includeIf']) || $button['includeIf'] == true): ?>
          <?php if(isset($button['href'])): ?>
            <a href="<?php echo e($button['href']); ?>" class="btn">
              <i class="fa <?php echo e($button['icon']); ?>"></i>
            </a>
            <?php else: ?>
            <button class="btn" 
              <?php if(isset($button['toggle'])): ?> data-toggle="<?php echo e($button['toggle']); ?>" <?php endif; ?>
              <?php if(isset($button['target'])): ?> data-target="<?php echo e($button['target']); ?>" <?php endif; ?>>
              <i class="fa <?php echo e($button['icon']); ?>"></i>
            </button>
          <?php endif; ?>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
  </div>
  <!-- Page Content -->
  <div class="content">
  <?php echo $__env->yieldContent('content'); ?>
  </div>
</main>