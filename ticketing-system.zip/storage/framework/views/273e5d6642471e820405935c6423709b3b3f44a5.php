<<?php echo e($wrapper['element'] ?? "span"); ?> class="row <?php echo e($wrapper['class'] ?? ""); ?>">
    <<?php echo e($label['element'] ?? "strong"); ?> class="<?php echo e($label['class'] ?? "col col-sm-12 col-md-3"); ?>"><?php echo e($label['name'] ?? "<field-name>"); ?>: </<?php echo e($label['element'] ?? "strong"); ?>>
    <<?php echo e($value['element'] ?? "span"); ?> class="<?php echo e($value['class'] ?? "col col-sm-12 col-md-9"); ?>">
    <?php if($value['is_html'] ?? false): ?>
        <?php echo $value['val'] ?? "<span>- Not set -</span>"; ?>

    <?php else: ?>
        <?php echo e($value['val'] ?? "- Not set -"); ?>

    <?php endif; ?>
    </<?php echo e($value['element'] ?? "span"); ?>>
</<?php echo e($wrapper['element'] ?? "span"); ?>>
