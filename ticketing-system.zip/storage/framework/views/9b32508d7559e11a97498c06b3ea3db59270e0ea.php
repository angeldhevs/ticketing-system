<select 
  <?php if(isset($id)): ?> id="<?php echo e($id); ?>" <?php endif; ?>
  <?php if(isset($name)): ?> name="<?php echo e($name); ?>" <?php endif; ?>
  class="mdb-select md-form <?php echo e($class ?? ""); ?>"
  <?php if($searchable ?? false): ?> searchable <?php endif; ?>
  >
  <?php if($defaultOption ?? true): ?>
    <option value="" disabled selected><?php echo e($defaultOptionLabel ?? "Select..."); ?></option>
  <?php endif; ?>
  <?php if(isset($options)): ?>
    <?php if(is_array($options)): ?>
      <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value= "<?php echo e($option->{$optionValue ?? "value"}); ?>"><?php echo e($option->{$optionName ?? "name"}); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  <?php endif; ?>

</select>