<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="dt-wrapper">
    <div class="dt-top-bar row">
      <div class="col col-sm-12 col-md-4 order-xs-last">
        <div class="input-group mb-2">
            <div class="input-group-prepend">
              <div class="input-group-text">
                <i class="fa fa-search"></i>
              </div>
            </div>
            <input type="search" name="searh" class="form-control form-control-sm col-10" aria-controls="tickets" placeholder="Search here" />
        </div>
      </div>
      <div class="col col-sm-12 col-md-8 order-xs-first text-right">
        <div class="button-group" role="group">
          <span data-toggle="tooltip" data-placement="right" title="New Ticket">
            <a href="<?php echo e(route('manage.roles.create')); ?>" class="btn btn-light border fa fa-plus"></a>
          </span>
        </div>
      </div>
    </div>
    <table class="table table-striped table-hover" style="width:100%">
      <thead>
        <tr>
          <th>Role</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
      <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td>
            <a href="<?php echo e(route('manage.roles.show', [ 'id' => $role->id ])); ?>">
              <?php echo e($role->name); ?>

            </a>
          </td>
          <td class="row-actions">
            <a href="<?php echo e(route('manage.roles.show', [ 'id' => $role->id ])); ?>" class="btn btn-sm" data-toggle="tooltip" data-placement="right" title="View role Details">
              <i class="fa fa-eye"></i>
            </a>
            <a href="<?php echo e(route('manage.roles.edit', [ 'id' => $role->id ])); ?>" class="btn btn-sm" data-toggle="tooltip" data-placement="right" title="Edit role Details">
              <i class="fa fa-edit"></i>
            </a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/modules/manage/roles.js')); ?>" ></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
  'pageTitle' => 'Manage Roles',
  'header' => [
    'icon' => 'fa-scroll',
    'text' => 'Roles'
  ]
], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>