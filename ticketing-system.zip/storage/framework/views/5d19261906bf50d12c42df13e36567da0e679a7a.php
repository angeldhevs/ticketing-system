<div class="container-fluid">
  <?php echo $__env->make('dashboard.components.ticket-count', [ 'title' => 'Tickets per Status', 'items' => $statuses ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('dashboard.components.ticket-count', [ 'title' => 'Tickets per Severity', 'items' => $severities ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>