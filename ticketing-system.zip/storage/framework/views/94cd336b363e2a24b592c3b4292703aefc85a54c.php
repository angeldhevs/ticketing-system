<?php
$hasheader = isset($header) && is_array($header);
?>

<nav class="navbar navbar-expand-lg navbar-laravel shadow">
  <div class="container-fluid">
    
    <button type="button" class="btn navbar-toggler toggler-left" data-target="#sidebar-left" data-toggle-class="show">
      <i class="fa fa-bars"></i>
    </button>

    <?php if($hasheader): ?> 
      <div class="navbar-page-title pl-md-2 pl-sm-0">
        <?php if(isset($header['icon'])): ?>
        <i class="header-icon fa <?php echo e($header['icon']); ?>"></i>
        <?php endif; ?>
        <?php if(isset($header['text'])): ?>
        <span><?php echo e($header['text']); ?></span>
        <?php elseif(isset($header['html'])): ?>
        <?php echo $header['html']; ?>

        <?php endif; ?>
      </div>
    <?php endif; ?>

    <button type="button" class="navbar-toggler toggler-right btn" data-toggle="collapse" data-toggle-class="collapse" data-target="#right-menu" aria-controls="rightMenu" aria-expanded="false" aria-label="Toggle navigation">
      <i class="fa fa-bars"></i>
    </button>
  
    <!-- Top-right menu -->
    <div class="collapse navbar-collapse" id="right-menu">
      <ul class="navbar-nav ml-md-auto mr-md-2 flex-sm-row justify-content-sm-center">
        <?php if(Auth::guest()): ?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
          </li>
        <?php else: ?>
          <li class="nav-item">
            <ul class="navbar-nav flex-sm-row justify-content-sm-center">
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <i class="fas fa-envelope"></i>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                  <i class="fas fa-bell"></i>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
              <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
            </a>
            <?php echo $__env->make('shared.logout-form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>