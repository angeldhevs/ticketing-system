<?php 
$content = [];
if(isset($buttons)) array_merge($content, [ 'buttons' => $buttons]);
if(isset($wrapperId)) array_merge($content, [ 'wrapperId' => $wrapperId]);
?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <title><?php echo !empty($pageTitle) ? $pageTitle." | " : ""; ?>Ticketing System</title>
  <!-- Section: Meta -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <!-- Section: Stylesheets -->
  <link rel="dns-prefetch" href="//fonts.gstatic.com">
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.11.0/build/css/themes/bootstrap.min.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<?php echo $__env->make('components.spinner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- You can specify one or more class from the partial view that uses this layout by supplying the following variables. -->
<body <?php if(isset($bodyClass)): ?>class=<?php echo e($bodyClass); ?><?php endif; ?>>
  <!-- Section: Content -->
  <?php if(auth()->check()): ?> 
    <div class="outer-wrapper">
      <?php echo $__env->make('shared.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="inner-wrapper">
        <?php echo $__env->make('shared.navbar', [ 'header' => $header] , \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('shared.content', $content, \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </div>
  <?php else: ?>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
  <?php endif; ?>

  <!-- Section: Scripts -->
  <script type="text/javascript" src="<?php echo e(asset('js/lib.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/utils.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/components.js')); ?>"></script>
  <script type="text/javascript">
      $(function() {
          // Include the csrf token for all ajax requests.
          $.ajaxSetup({
              headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              }
          });

          //Global: shows a spinner when submitting a form.
          $(document).on('submit', 'form', function(evt) {
              $.spinner('show');
              $(evt.currentTarget)
                  .find('[type=submit]')
                  .addClass('disabled')
                  .attr('disabled', true);

              return true;
          });
      });
  </script>
  <?php if(Session::has('alert')): ?>
  $alert = <?php echo e(Session::get('alert')); ?>

  dd($alert);
  //If status is set, show a toast notification.
  <script type="text/javascript">
    $(function() {
      let alert = <?php echo json_encode($alert); ?>

      console.log(alert);
      toastr[alert.type](alert.message);
    });
  </script>
  <?php endif; ?>
  <!-- Render custom scripts from partial views -->
  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
