<?php if((isset($src) && is_array($src)) &&
  (isset($name) && is_string($name)) &&
  (isset($src[$name]))): ?>
  <?php $__currentLoopData = $src[$name]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php switch(true):
      case (is_object($element)): ?>
        <?php echo e($name !== 'attr' ? $name.'-' : ''); ?>.<?php echo e(key($element)."=\"".$element."\""); ?>

        <?php break; ?>
      <?php case (is_string($element)): ?>
        <?php echo e($element); ?>

        <?php break; ?>
    <?php endswitch; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

