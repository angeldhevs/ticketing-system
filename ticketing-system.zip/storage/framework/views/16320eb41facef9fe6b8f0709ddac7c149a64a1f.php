<?php
  $current_role = Auth::user()->roles->first()->name;
  $current_role = trim(str_replace(' ', '_', $current_role));
?>



<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row mt-2">
    <div class="col col-md-12 mt-sm-2">
      <?php echo $__env->make('dashboard.charts.new-vs-closed-tickets', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
  <div class="row">
    <div class="col col-md-12 col-lg-6 mt-sm-2">
      <?php echo $__env->make('dashboard.charts.tickets-per-status', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col col-md-12 col-lg-6 mt-sm-2">
      <?php echo $__env->make('dashboard.charts.tickets-per-severity', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/modules/dashboard.js')); ?>" ></script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', [
  'pageTitle' => 'Dashboard',
  'header' => [
    'icon' => 'fa-tachometer-alt',
    'text' => 'Dashboard'
  ]
], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>