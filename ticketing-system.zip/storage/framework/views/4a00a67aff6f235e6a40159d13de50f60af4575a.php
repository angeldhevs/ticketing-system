<div class="charts-and-tables grid-stack">
  <?php echo $__env->make('dashboard.tables.recent-ticket-updates', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('dashboard.charts.tickets-by-status', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('dashboard.charts.tickets-by-severity', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>