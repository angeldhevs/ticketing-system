<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="dt-wrapper">
        <div class="dt-top-bar row">
            <div class="col col-sm-12 col-md-4 order-xs-last">
                <div class="input-group mb-2">
                    <div class="input-group-prepend">
                    <div class="input-group-text">
                        <i class="fa fa-search"></i>
                    </div>
                    </div>
                    <input type="search" name="searh" class="form-control form-control-sm col-10" aria-controls="tickets" placeholder="Search here" />
                </div>
            </div>
        </div>
        <table class="table table-striped table-hover" style="width:100%">
            <thead>
                <tr>
                    <th>Assignee</th>
                    <th>
                        <span class="badge badge-success">Closed</span>
                    </th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($agent->name); ?></td>
                    <td><?php echo e($agent->count_tickets()); ?></td>
                    <td><?php echo e($agent->count_tickets()); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/reports-module.js')); ?>" ></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
  'pageTitle' => 'Reports',
  'header' => [
    'icon' => 'fa-chart-area',
    'text' => 'Reports'
  ]
], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>