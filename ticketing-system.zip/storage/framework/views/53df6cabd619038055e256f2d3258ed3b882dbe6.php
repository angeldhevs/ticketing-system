<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="dt-wrapper">
    <div class="dt-top-bar row">
      <div class="col col-sm-12 col-md-4 order-xs-last">
        <div class="input-group mb-2">
            <div class="input-group-prepend">
              <div class="input-group-text">
                <i class="fa fa-search"></i>
              </div>
            </div>
            <input type="search" name="searh" class="form-control form-control-sm col-10" aria-controls="tickets" placeholder="Search here" />
        </div>
      </div>
      <div class="col col-sm-12 col-md-8 order-xs-first text-right">
        <div class="button-group" role="group">
          <span data-toggle="tooltip" data-placement="right" title="New Ticket">
            <a href="<?php echo e(route('manage.users.create')); ?>" class="btn btn-light border fa fa-plus"></a>
          </span>
        </div>
      </div>
    </div>
    <table class="table table-striped table-hover" style="width:100%">
      <thead>
        <tr>
          <th>Name</th>
          <th>Role</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td>
            <a href="<?php echo e(route('manage.users.show', [ 'id' => $user->id ])); ?>">
              <?php echo e($user->name); ?>

            </a>
            <br />
            <small class="text-muted">
              <?php echo e($user->email); ?>

            </small>
          </td>
          <td>
              <?php echo e(implode($user->roles->pluck('name')->toArray())); ?>

          </td>
          <td class="row-actions">
            <a href="<?php echo e(route('manage.users.show', [ 'id' => $user->id ])); ?>" class="btn btn-sm" data-toggle="tooltip" data-placement="right" title="View User Details">
              <i class="fa fa-eye"></i>
            </a>
            <a href="<?php echo e(route('manage.users.edit', [ 'id' => $user->id ])); ?>" class="btn btn-sm" data-toggle="tooltip" data-placement="right" title="Edit User Details">
              <i class="fa fa-edit"></i>
            </a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/modules/manage/users.js')); ?>" ></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
  'pageTitle' => 'Manage Users',
  'header' => [
    'icon' => 'fa-users',
    'text' => 'Users'
  ]
], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>