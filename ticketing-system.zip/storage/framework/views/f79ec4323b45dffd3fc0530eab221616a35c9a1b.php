<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
  <div class="row">
    <div class="col col-sm-12 col-md-6">
      <form method="POST" action="<?php echo e(route('users.update', [ 'id' => $user->id ])); ?>"  data-method="PATCH">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <input type="hidden" value="<?php echo e($user->id); ?>" name="id">
        <?php echo $__env->make('components.input', [
          'name' => 'name',
          'placeholder' => 'Enter '.__('Name'),
          'value' => old('name') ?? $user->name,
          'class' => $errors->has('name') ? 'is-invalid' : '',
          'attr' => [
              'required',
              'autofocus',
              'autocomplete' => 'off'
          ],
          'label' => [
              'text' => __('Name'),
              'class' => 'col-md-4 col-form-label text-md-right'
          ],
          'wrappers' => [
              'outer' => [ 'class' => 'form-group row' ],
              'inner' => [ 'class' => 'col-sm-12 col-md-8' ]
          ],
          'error' => [
              'tag' => 'small',
              'html' => '<strong>'.$errors->first('name').'</strong>'
          ]
        ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('components.input', [
          'name' => 'email',
          'type' => 'email',
          'placeholder' => 'Enter '.__('E-Mail Address'),
          'value' =>  old('email') ?? $user->email,
          'class' => $errors->has('email') ? ' is-invalid' : '',
          'attr' => [
              'required',
              'autocomplete' => 'off'
          ],
          'label' => [
              'text' => __('E-Mail Address'),
              'class' => 'col-md-4 col-form-label text-md-right'
          ],
          'wrappers' => [
              'outer' => [ 'class' => 'form-group row' ],
              'inner' => [ 'class' => 'col-sm-12 col-md-8' ]
          ],
          'error' => [
              'tag' => 'small',
              'html' => '<strong>'.$errors->first('email').'</strong>'
          ]
        ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('components.select', [
          'name' => 'role_id',
          'options' => $roles,
          'optionValue' => 'id',
          'optionText' => 'name',
          'selectedOption' => old('role_id') ?? $user->roles[0]->id,
          'label' => [
              'text' => 'Role',
              'class' => 'col-md-4 col-form-label text-md-right'
          ],
          'wrappers' => [
              'outer' => [ 'class' => 'form-group row' ],
              'inner' => [ 'class' => 'col-sm-12 col-md-8' ]
          ],
          'defaultOption' => [ 'text' => 'Select...' ]
        ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="form-group row mb-0">
          <div class="col-md-6 offset-md-4">
            <button type="submit" class="btn btn-primary">
              <?php echo e(__('Update')); ?>

            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/modules/manage/users.js')); ?>" ></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
  'pageTitle' => 'Edit User',
  'header' => [
    'icon' => 'fa-user-edit',
    'text' => 'Edit User'
  ]
], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>