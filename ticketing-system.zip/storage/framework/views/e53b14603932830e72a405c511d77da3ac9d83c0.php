<?php
$status_context = ['info', 'primary', 'warning', 'success'];
$severity_context = ['info', 'primary', 'warning', 'danger'];
$severity_color = $severity_context[$ticket->severity->id - 1];
$status_color = $status_context[$ticket->current()->status->id - 1];
?>





<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row p-1">
    <div class="col col-sm-12 col-md-6">
      <?php echo $__env->make('components.display-field', [
        'wrapper' => [ 'class' => 'text-muted' ],
        'label' => [ 'name' => 'Source' ],
        'value' => [ 'val' => $ticket->source->name ]
      ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col col-sm-12 col-md-6">
      <?php echo $__env->make('components.display-field', [
        'wrapper' => [ 'class' => 'text-muted' ],
        'label' => [ 'name' => 'Created' ],
        'value' => [ 'val' => $ticket->created_at->diffForHumans() ]
      ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
  <div class="row p-1">
    <div class="col col-sm-12 col-md-6">
      <?php echo $__env->make('components.display-field', [
        'wrapper' => [ 'class' => 'text-muted' ],
        'label' => [ 'name' => 'Assignee' ],
        'value' => [ 'val' => $ticket->current()->asignee->name ]
      ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col col-sm-12 col-md-6">
      <?php echo $__env->make('components.display-field', [
        'wrapper' => [ 'class' => 'text-muted' ],
        'label' => [ 'name' => 'Assigned by' ],
        'value' => [ 'val' => $ticket->current()->reporter->name ]
      ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
  <div class="row p-1">
    <div class="col col-sm-12 col-md-6">
      <?php echo $__env->make('components.display-field', [
        'wrapper' => [ 'class' => 'text-muted' ],
        'label' => [ 'name' => 'Severity' ],
        'value' => [ 
          'val' => '
            <span class="p-2 badge badge-'.$severity_color.'">'
              .$ticket->severity->name.
            '</span>', 
          'is_html' => true  
        ]
      ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col col-sm-12 col-md-6">
      <?php echo $__env->make('components.display-field', [
        'wrapper' => [ 'class' => 'text-muted' ],
        'label' => [ 'name' => 'Status' ],
        'value' => [ 
          'val' => '
            <span class="p-2 badge badge-'.$status_color.'">'
              .$ticket->current()->status->name.
            '</span>', 
          'is_html' => true  
        ]
      ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
  </div>
  <div class="row p-1">
    <div class="form-group col-sm-12 text-muted">
      <strong>Details : </strong>
      <textarea id="ticket_details" class="form-control disabled" name="ticket_severity" rows="5" disabled="disabled"><?php echo e($ticket->details); ?></textarea>
    </div>
  </div>
  <?php echo $__env->make('ticket.history', [ 'ticket_progress' => $ticket->progress ], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- Modal -->
  <div class="modal fade bd-example-modal-lg" id="modalUpdateTicket" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <form class="modal-dialog modal-lg" role="document" method="PUT">
          <div class="modal-content">
              <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Update Ticket</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                  </button>
              </div>
              <div class="modal-body">
                  <input type="hidden" id="ticket_id" name="ticket_id" value="<?php echo e($ticket->id); ?>">
                  <input type="hidden" id="assignee_id" name="assignee_id" value="<?php echo e($ticket->current()->asignee->id); ?>">
                  <input type="hidden" id="reporter_id" name="reporter_id" value="<?php echo e($ticket->current()->reporter->id); ?>">
                  <div class="row p-1">
                      <div class="col col-sm-12 col-md-6">
                              <span class="card-text">
                                  <strong>Source : </strong>
                                  <?php echo e($ticket->source->name); ?>

                              </span>
                      </div>
                      <div class="col col-sm-12 col-md-6">
                              <span class="card-text">
                                  <strong>Created : </strong>
                                  <?php echo e($ticket->created_at->diffForHumans()); ?>

                              </span>
                      </div>
                  </div>
                  <div class="row p-1">
                      <div class="col col-sm-12 col-md-6">
                              <span class="card-text">
                                  <strong>Reporter : </strong>
                                  <?php echo e($ticket->current()->reporter->name); ?>

                              </span>
                      </div>
                      <div class="col col-sm-12 col-md-6">
                              <span class="card-text">
                                  <strong>Assignee : </strong>
                                  <?php echo e($ticket->current()->asignee->name); ?>

                              </span>
                      </div>
                  </div>
                  <div class="row p-1">
                      <div class="col col-sm-12 col-md-6">
                              <span class="card-text">
                                  <strong>Severity : </strong>
                                  <?php echo e($ticket->severity->name); ?>

                              </span>
                      </div>
                      <div class="col col-sm-12 col-md-6">
                              <span class="card-text">
                                  <strong>Status : </strong>
                                   <select id="status" class="form">
                                       <?php $__currentLoopData = $ticket_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket_stats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($ticket_stats->id); ?>"><?php echo e($ticket_stats->name); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </select>
                              </span>
                      </div>
                      <div class="col-md-12">
                          <span class="card-text">
                          <strong>Remarks : </strong>
                          <textarea class="form-control" id="ticket_remarks" rows="5"></textarea>
                          </span>
                      </div>
                  </div>
              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary" id="btnUpdateTicket">Save changes</button>
              </div>
          </div>
      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/ticket/update.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/ticket/view.css')); ?>"></link>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
  'pageTitle' => 'Ticket '.$ticket->ticket_number,
  'header' => [
    'html' => 
      '<strong class="badge badge-'.$severity_color.'">
        <i class="fa fa-ticket-alt"></i>'
          .$ticket->ticket_number.
      '</strong>'
        .$ticket->title
  ]
], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', [
  'title' => 'Ticket Details', 
  'bodyClass' => 'view-ticket', 
  'wrapperClass' => 'container mt-2'
], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>