<div id="tickets-per-severity" class="ticket-counts">
  <h6><?php echo e($title); ?></h6>
  <ul class="list-group list-group-horizontal">
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="list-group-item flex-fill text-center" data-id="<?php echo e($item->id); ?>">
      <h1>
        <strong>
          <?php echo e(count($item->tickets)); ?>

        </strong>
      </h1>
      <strong>
        <?php echo e($item->name); ?>

      </strong>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>