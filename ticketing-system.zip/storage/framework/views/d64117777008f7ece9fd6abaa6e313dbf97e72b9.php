<?php
$is_admin = Auth::user()->has_role('admin')
?>



<?php $__env->startSection('content'); ?>
<h2>
  <?php if($is_admin): ?>
  All Tickets
  <?php else: ?>
  Your Tickets
  <?php endif; ?>
</h2>
<hr />
<?php if(session('status')): ?>
  <div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

  </div>
<?php endif; ?>
<div class="dt-wrapper">
  <div class="dt-top-bar row">
    <div class="col col-sm-12 col-md-4 order-xs-last">
      <div class="input-group mb-2">
          <div class="input-group-prepend">
            <div class="input-group-text">
              <i class="fa fa-search"></i>
            </div>
          </div>
          <input type="search" name="searh" class="form-control form-control-sm col-10" aria-controls="tickets" placeholder="Search here" />
      </div>
    </div>
    <div class="col col-sm-12 col-md-8 order-xs-first text-right">
      <div class="button-group" role="group">
        <?php if($is_admin): ?>
        <span data-toggle="tooltip" data-placement="right" title="New Ticket">
          <button type="button" class="btn btn-light border fa fa-plus"  data-toggle="modal" data-target="#ticket-form" ></button>
        </span>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <table id="tickets" class="table table-striped table-hover" style="width:100%">
      <thead>
          <tr>
              <th>Ticket #</th>
              <th>Title</th>
              <th>Severity</th>
              <th>Status</th>
              <th>Last Update</th>
              <th>Action</th>
          </tr>
      </thead>
      <tbody>
      <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <td>
                  <a href="/tickets/<?php echo e($ticket->id); ?>">
                      <?php echo e($ticket->ticket_number); ?>

                  </a>
              </td>
              <td>
                  <?php echo e($ticket->title); ?>

                  <br />
                  <small class="text-muted">Added <?php echo e($ticket->created_at->diffForHumans()); ?></small>
              </td>
              <td><?php echo e($ticket->severity->name); ?></td>
              <td><?php echo e($ticket->current()->status->name); ?></td>
              <td><?php echo e($ticket->current()->created_at->diffForHumans()); ?></td>
              <td class="text-left">
                  <a href="/tickets/<?php echo e($ticket->id); ?>" data-toggle="tooltip" data-placement="right" title="View Ticket Details" >
                      <i class="fa fa-eye"></i>
                  </a>
                  <?php if($is_admin && !$ticket->hasProgress()): ?>
                  <a href="/tickets/<?php echo e($ticket->id); ?>/assign" data-toggle="tooltip" data-placement="right" title="Assign Agent">
                      <i class="fa fa-user-plus"></i>
                  </a>
                  <?php endif; ?>
              </td>
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>
</div>
<?php if($is_admin): ?>
<?php echo $__env->make('ticket.create', $createTicket, \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
    <link href="<?php echo e(asset('css/dashboard.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php if($is_admin): ?>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js" ></script>
    <script type="text/javascript" src="/js/ticket/form.js" ></script>
    <?php endif; ?>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" ></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js" ></script>
    <script type="text/javascript" src="/js/dashboard.js" ></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
  'title' => 'Dashboard', 
  'bodyClass' => 'dashboard', 
  'wrapperClass' => 'container mt-4'
], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>